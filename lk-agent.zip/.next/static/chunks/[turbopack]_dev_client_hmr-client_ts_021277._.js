(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/[turbopack]_dev_client_hmr-client_ts_e44986._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/[turbopack]_dev_client_hmr-client_ts_e44986._.js",
  "chunks": [
    "static/chunks/[turbopack]_dev_client_hmr-client_ts_25e373._.js"
  ],
  "source": "dynamic"
});
