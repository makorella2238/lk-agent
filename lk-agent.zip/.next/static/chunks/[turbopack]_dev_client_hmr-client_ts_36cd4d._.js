(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/[turbopack]_dev_client_hmr-client_ts_36cd4d._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/[turbopack]_dev_client_hmr-client_ts_36cd4d._.js",
  "chunks": [
    "static/chunks/[turbopack]_dev_client_hmr-client_ts_312b2a._.js"
  ],
  "source": "dynamic"
});
