(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/[turbopack]_dev_client_hmr-client_ts_33e4e5._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/[turbopack]_dev_client_hmr-client_ts_33e4e5._.js",
  "chunks": [
    "static/chunks/[turbopack]_dev_client_hmr-client_ts_994715._.js"
  ],
  "source": "dynamic"
});
