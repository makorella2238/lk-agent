(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/[next]_entry_page-loader_ts_01330f._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/[next]_entry_page-loader_ts_01330f._.js",
  "chunks": [
    "static/chunks/node_modules_next_730006._.js",
    "static/chunks/node_modules_react_b2385d._.js",
    "static/chunks/node_modules_react-dom_cjs_react-dom_development_ab7e07.js",
    "static/chunks/node_modules_react-dom_f14d04._.js",
    "static/chunks/node_modules_633750._.js",
    "static/chunks/[root of the server]__272bc4._.js",
    "static/chunks/node_modules_next_dist_pages_a43a81._.js"
  ],
  "source": "entry"
});
