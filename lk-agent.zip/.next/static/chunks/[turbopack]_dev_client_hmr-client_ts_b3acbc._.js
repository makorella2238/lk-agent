(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/[turbopack]_dev_client_hmr-client_ts_021277._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/[turbopack]_dev_client_hmr-client_ts_021277._.js",
  "chunks": [
    "static/chunks/[turbopack]_dev_client_hmr-client_ts_98437a._.js"
  ],
  "source": "dynamic"
});
