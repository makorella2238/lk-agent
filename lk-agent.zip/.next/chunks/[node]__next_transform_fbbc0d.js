(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "chunks/[node]__next_transform_fbbc0d.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "chunks/[node]__next_transform_fbbc0d.js",
  "chunks": [
    "chunks/[turbopack-node]__fbc971._.js",
    "chunks/postcss_config_js_transform_ts_45949a._.js"
  ],
  "source": "entry"
});
