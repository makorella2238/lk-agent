(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "chunks/postcss_config_js_transform_ts_f5bd92._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "chunks/postcss_config_js_transform_ts_f5bd92._.js",
  "chunks": [
    "chunks/postcss_config_js_transform_ts_71c0f0._.js"
  ],
  "source": "dynamic"
});
