const CHUNK_PUBLIC_PATH = "server/app/drivers/[driverId]/orders/page.js";
const runtime = require("../../../../chunks/[turbopack]_runtime.js");
runtime.loadChunk("server/chunks/node_modules_2c6786._.js");
runtime.loadChunk("server/chunks/[root of the server]__394deb._.js");
runtime.getOrInstantiateRuntimeModule("[project]/.next-internal/server/app/drivers/[driverId]/orders/page/actions.js (ecmascript)", CHUNK_PUBLIC_PATH);
module.exports = runtime.getOrInstantiateRuntimeModule("[project]/node_modules/next/dist/esm/build/templates/app-page.js/(COMPONENT_0)/[project]/src/app/layout.tsx [app-rsc] (ecmascript, Next.js server component)/(COMPONENT_1)/[project]/node_modules/next/dist/client/components/not-found-error.js [app-rsc] (ecmascript, Next.js server component)/(COMPONENT_2)/[project]/src/app/drivers/[driverId]/orders/page.tsx [app-rsc] (ecmascript, Next.js server component) (ecmascript) {facade}", CHUNK_PUBLIC_PATH).exports;
