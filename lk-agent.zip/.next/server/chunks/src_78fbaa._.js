module.exports = {

"[project]/src/utils/tablePagitaion.tsx [app-ssr] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_require_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, l: __turbopack_load__, j: __turbopack_dynamic__, p: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "renderPagination": ()=>renderPagination
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/server/future/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__Button$7d$__ = __turbopack_import__("[project]/node_modules/@material-ui/core/esm/Button/Button.js [app-ssr] (ecmascript) {export default as Button}");
"__TURBOPACK__ecmascript__hoisting__location__";
;
;
const renderPagination = (currentPage, total, pageSize, handleChangePage)=>{
    const pagesCount = Math.ceil(total / pageSize);
    const pages = [];
    for(let i = 1; i <= pagesCount; i++){
        pages.push(i);
    }
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("div", {
        className: "flex justify-center mt-3",
        children: pages.map((page)=>/*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__Button$7d$__["Button"], {
                variant: currentPage === page ? 'contained' : 'outlined',
                color: currentPage === page ? 'primary' : 'default',
                className: "m-1",
                onClick: ()=>handleChangePage(page),
                children: page
            }, page, false, {
                fileName: "<[project]/src/utils/tablePagitaion.tsx>",
                lineNumber: 14,
                columnNumber: 17
            }, this))
    }, void 0, false, {
        fileName: "<[project]/src/utils/tablePagitaion.tsx>",
        lineNumber: 12,
        columnNumber: 9
    }, this);
};

})()),
"[project]/src/utils/formateDate.ts [app-ssr] (ecmascript)": (function({ r: __turbopack_require__, f: __turbopack_require_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, l: __turbopack_load__, j: __turbopack_dynamic__, p: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: require }) { !function() {

const e = new Error("Could not parse module '[project]/src/utils/formateDate.ts'");
e.code = 'MODULE_UNPARSEABLE';
throw e;
}.call(this) }),
"[project]/src/components/screen/OrderTable/OrderTable.tsx [app-ssr] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_require_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, l: __turbopack_load__, j: __turbopack_dynamic__, p: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "default": ()=>__TURBOPACK__default__export__,
    "formatCategory": ()=>formatCategory,
    "getStatusLabel": ()=>getStatusLabel
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/server/future/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/server/future/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$Dialog$2f$Dialog$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__Dialog$7d$__ = __turbopack_import__("[project]/node_modules/@material-ui/core/esm/Dialog/Dialog.js [app-ssr] (ecmascript) {export default as Dialog}");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$DialogActions$2f$DialogActions$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__DialogActions$7d$__ = __turbopack_import__("[project]/node_modules/@material-ui/core/esm/DialogActions/DialogActions.js [app-ssr] (ecmascript) {export default as DialogActions}");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$DialogContent$2f$DialogContent$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__DialogContent$7d$__ = __turbopack_import__("[project]/node_modules/@material-ui/core/esm/DialogContent/DialogContent.js [app-ssr] (ecmascript) {export default as DialogContent}");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$DialogTitle$2f$DialogTitle$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__DialogTitle$7d$__ = __turbopack_import__("[project]/node_modules/@material-ui/core/esm/DialogTitle/DialogTitle.js [app-ssr] (ecmascript) {export default as DialogTitle}");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$MenuItem$2f$MenuItem$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__MenuItem$7d$__ = __turbopack_import__("[project]/node_modules/@material-ui/core/esm/MenuItem/MenuItem.js [app-ssr] (ecmascript) {export default as MenuItem}");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$Paper$2f$Paper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__Paper$7d$__ = __turbopack_import__("[project]/node_modules/@material-ui/core/esm/Paper/Paper.js [app-ssr] (ecmascript) {export default as Paper}");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$Table$2f$Table$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__Table$7d$__ = __turbopack_import__("[project]/node_modules/@material-ui/core/esm/Table/Table.js [app-ssr] (ecmascript) {export default as Table}");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$TableBody$2f$TableBody$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__TableBody$7d$__ = __turbopack_import__("[project]/node_modules/@material-ui/core/esm/TableBody/TableBody.js [app-ssr] (ecmascript) {export default as TableBody}");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$TableCell$2f$TableCell$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__TableCell$7d$__ = __turbopack_import__("[project]/node_modules/@material-ui/core/esm/TableCell/TableCell.js [app-ssr] (ecmascript) {export default as TableCell}");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$TableHead$2f$TableHead$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__TableHead$7d$__ = __turbopack_import__("[project]/node_modules/@material-ui/core/esm/TableHead/TableHead.js [app-ssr] (ecmascript) {export default as TableHead}");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$TableRow$2f$TableRow$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__TableRow$7d$__ = __turbopack_import__("[project]/node_modules/@material-ui/core/esm/TableRow/TableRow.js [app-ssr] (ecmascript) {export default as TableRow}");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__TextField$7d$__ = __turbopack_import__("[project]/node_modules/@material-ui/core/esm/TextField/TextField.js [app-ssr] (ecmascript) {export default as TextField}");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/navigation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$TableContainer$2f$TableContainer$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@material-ui/core/esm/TableContainer/TableContainer.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$genetal$2d$css$2f$general$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__ = __turbopack_import__("[project]/src/components/ui/genetal-css/general.module.css [app-ssr] (css module)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$tablePagitaion$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/utils/tablePagitaion.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$formateData$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/utils/formateData.ts [app-ssr] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
'use client';
;
;
;
;
;
;
;
;
const formatCategory = (category)=>{
    switch(category){
        case 'food':
            return 'Еда';
        case 'product':
            return 'Товары';
        case 'package':
            return 'Посылка';
        default:
            return 'Неизвестно';
    }
};
const getStatusLabel = (status)=>{
    switch(status){
        case -4:
            return 'Отменён клиентом';
        case -3:
            return 'Отменён поддержкой сервиса';
        case -2:
            return 'Отменён курьером';
        case -1:
            return 'Отменён заведением';
        case 0:
            return 'Опубликован';
        case 1:
            return 'Курьер на пути к точке А';
        case 2:
            return 'Курьер в точке А';
        case 3:
            return 'Забран, на пути в точку Б';
        case 4:
            return 'Курьер в точке Б';
        case 5:
            return 'Отработан';
        default:
            return '';
    }
};
const OrderTable = ({ data, pageSize, setOffset, offset })=>{
    const router = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRouter"]();
    // @ts-ignore
    const total = data.total;
    const [openModal, setOpenModal] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"](false);
    const [currentPage, setCurrentPage] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"](1);
    const [carFilter, setCarFilter] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"]('');
    const [statusFilter, setStatusFilter] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"]('');
    const [categoryFilter, setCategoryFilter] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"]('');
    const [dateFilter, setDateFilter] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"]({
        startDate: '',
        endDate: ''
    });
    const [isFilterApplied, setIsFilterApplied] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"](false); // Добавлено новое состояние
    const getCurrentPageOrders = ()=>{
        if (!data || !data.orders) {
            return []; // Return an empty array if data or orders are undefined
        }
        let filteredOrders = data.orders; // Define filteredOrders variable
        if (isFilterApplied) {
            if (carFilter) {
                filteredOrders = filteredOrders.filter((order)=>order.carName.toLowerCase().includes(carFilter.toLowerCase()));
            }
            if (statusFilter) {
                const status = parseInt(statusFilter);
                filteredOrders = filteredOrders.filter((order)=>order.status === status);
            }
            if (categoryFilter) {
                filteredOrders = filteredOrders.filter((order)=>order.type === categoryFilter);
            }
            if (dateFilter.startDate && dateFilter.endDate) {
                filteredOrders = filteredOrders.filter((order)=>{
                    const orderDate = new Date(order.dateTimeCourierDone);
                    const startDate = new Date(dateFilter.startDate);
                    const endDate = new Date(dateFilter.endDate);
                    return orderDate >= startDate && orderDate <= endDate;
                });
            }
        }
        const startIndex = offset;
        const endIndex = offset + pageSize;
        return filteredOrders.slice(startIndex, endIndex);
    };
    const handleCarFilterChange = (event)=>{
        setCarFilter(event.target.value);
    };
    const handleStatusFilterChange = (event)=>{
        setStatusFilter(event.target.value);
    };
    const handleCategoryFilterChange = (event)=>{
        setCategoryFilter(event.target.value);
    };
    const handleDateFilterChange = (event)=>{
        const { name, value } = event.target;
        setDateFilter((prevState)=>({
                ...prevState,
                [name]: value
            }));
    };
    const handleChangePage = (page)=>{
        const newOffset = (page - 1) * pageSize;
        setOffset(newOffset);
        setCurrentPage(page);
    };
    const handleApplyFilter = ()=>{
        handleFilter();
        setIsFilterApplied(true);
        setOpenModal(false);
    };
    const handleFilter = ()=>{
        setIsFilterApplied(true);
        setCurrentPage(1);
    };
    const handleResetFilter = ()=>{
        setCarFilter('');
        setStatusFilter('');
        setCategoryFilter('');
        setDateFilter({
            startDate: '',
            endDate: ''
        });
        setIsFilterApplied(false);
    };
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("div", {
        className: "mx-5",
        children: [
            /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("h1", {
                className: "text-center font-bold my-3 ml-3 text-2xl ",
                children: "Заказы"
            }, void 0, false, {
                fileName: "<[project]/src/components/screen/OrderTable/OrderTable.tsx>",
                lineNumber: 176,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("button", {
                className: `float-right mb-2 sm:mb-4 ${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$genetal$2d$css$2f$general$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].BaseButton}`,
                onClick: ()=>setOpenModal(true),
                children: "Фильтровать"
            }, void 0, false, {
                fileName: "<[project]/src/components/screen/OrderTable/OrderTable.tsx>",
                lineNumber: 179,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$TableContainer$2f$TableContainer$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                component: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$Paper$2f$Paper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__Paper$7d$__["Paper"],
                children: /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$Paper$2f$Paper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__Paper$7d$__["Paper"], {
                    children: /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$Table$2f$Table$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__Table$7d$__["Table"], {
                        children: [
                            /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$TableHead$2f$TableHead$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__TableHead$7d$__["TableHead"], {
                                children: /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$TableRow$2f$TableRow$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__TableRow$7d$__["TableRow"], {
                                    children: [
                                        /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$TableCell$2f$TableCell$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__TableCell$7d$__["TableCell"], {
                                            children: "Номер заказа"
                                        }, void 0, false, {
                                            fileName: "<[project]/src/components/screen/OrderTable/OrderTable.tsx>",
                                            lineNumber: 188,
                                            columnNumber: 33
                                        }, this),
                                        /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$TableCell$2f$TableCell$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__TableCell$7d$__["TableCell"], {
                                            children: "Автомобиль"
                                        }, void 0, false, {
                                            fileName: "<[project]/src/components/screen/OrderTable/OrderTable.tsx>",
                                            lineNumber: 189,
                                            columnNumber: 33
                                        }, this),
                                        /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$TableCell$2f$TableCell$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__TableCell$7d$__["TableCell"], {
                                            children: "Категория"
                                        }, void 0, false, {
                                            fileName: "<[project]/src/components/screen/OrderTable/OrderTable.tsx>",
                                            lineNumber: 190,
                                            columnNumber: 33
                                        }, this),
                                        /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$TableCell$2f$TableCell$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__TableCell$7d$__["TableCell"], {
                                            children: "Дата и время принятия"
                                        }, void 0, false, {
                                            fileName: "<[project]/src/components/screen/OrderTable/OrderTable.tsx>",
                                            lineNumber: 191,
                                            columnNumber: 33
                                        }, this),
                                        /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$TableCell$2f$TableCell$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__TableCell$7d$__["TableCell"], {
                                            children: "Дата и время подачи"
                                        }, void 0, false, {
                                            fileName: "<[project]/src/components/screen/OrderTable/OrderTable.tsx>",
                                            lineNumber: 192,
                                            columnNumber: 33
                                        }, this),
                                        /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$TableCell$2f$TableCell$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__TableCell$7d$__["TableCell"], {
                                            children: "Дата и время завершения"
                                        }, void 0, false, {
                                            fileName: "<[project]/src/components/screen/OrderTable/OrderTable.tsx>",
                                            lineNumber: 193,
                                            columnNumber: 33
                                        }, this),
                                        /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$TableCell$2f$TableCell$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__TableCell$7d$__["TableCell"], {
                                            children: "Статус"
                                        }, void 0, false, {
                                            fileName: "<[project]/src/components/screen/OrderTable/OrderTable.tsx>",
                                            lineNumber: 194,
                                            columnNumber: 33
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "<[project]/src/components/screen/OrderTable/OrderTable.tsx>",
                                    lineNumber: 187,
                                    columnNumber: 29
                                }, this)
                            }, void 0, false, {
                                fileName: "<[project]/src/components/screen/OrderTable/OrderTable.tsx>",
                                lineNumber: 186,
                                columnNumber: 25
                            }, this),
                            /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$TableBody$2f$TableBody$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__TableBody$7d$__["TableBody"], {
                                children: getCurrentPageOrders().length > 0 ? getCurrentPageOrders().map((order)=>/*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$TableRow$2f$TableRow$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__TableRow$7d$__["TableRow"], {
                                        onClick: ()=>router.push(`orders/${order.id}`),
                                        children: [
                                            /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$TableCell$2f$TableCell$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__TableCell$7d$__["TableCell"], {
                                                children: order.uid
                                            }, void 0, false, {
                                                fileName: "<[project]/src/components/screen/OrderTable/OrderTable.tsx>",
                                                lineNumber: 202,
                                                columnNumber: 41
                                            }, this),
                                            /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$TableCell$2f$TableCell$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__TableCell$7d$__["TableCell"], {
                                                children: order.carName
                                            }, void 0, false, {
                                                fileName: "<[project]/src/components/screen/OrderTable/OrderTable.tsx>",
                                                lineNumber: 203,
                                                columnNumber: 41
                                            }, this),
                                            /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$TableCell$2f$TableCell$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__TableCell$7d$__["TableCell"], {
                                                children: formatCategory(order.type)
                                            }, void 0, false, {
                                                fileName: "<[project]/src/components/screen/OrderTable/OrderTable.tsx>",
                                                lineNumber: 204,
                                                columnNumber: 41
                                            }, this),
                                            /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$TableCell$2f$TableCell$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__TableCell$7d$__["TableCell"], {
                                                children: order.dateTimeCourierAccept && __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$formateData$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["formatDateAndClock"](order.dateTimeCourierAccept)
                                            }, void 0, false, {
                                                fileName: "<[project]/src/components/screen/OrderTable/OrderTable.tsx>",
                                                lineNumber: 205,
                                                columnNumber: 41
                                            }, this),
                                            /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$TableCell$2f$TableCell$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__TableCell$7d$__["TableCell"], {
                                                children: order.dateTimeCourierPickUp && __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$formateData$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["formatDateAndClock"](order.dateTimeCourierPickUp)
                                            }, void 0, false, {
                                                fileName: "<[project]/src/components/screen/OrderTable/OrderTable.tsx>",
                                                lineNumber: 206,
                                                columnNumber: 41
                                            }, this),
                                            /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$TableCell$2f$TableCell$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__TableCell$7d$__["TableCell"], {
                                                children: order.dateTimeCourierDone && __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$formateData$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["formatDateAndClock"](order.dateTimeCourierDone)
                                            }, void 0, false, {
                                                fileName: "<[project]/src/components/screen/OrderTable/OrderTable.tsx>",
                                                lineNumber: 207,
                                                columnNumber: 41
                                            }, this),
                                            /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$TableCell$2f$TableCell$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__TableCell$7d$__["TableCell"], {
                                                children: getStatusLabel(order.status)
                                            }, void 0, false, {
                                                fileName: "<[project]/src/components/screen/OrderTable/OrderTable.tsx>",
                                                lineNumber: 208,
                                                columnNumber: 41
                                            }, this)
                                        ]
                                    }, order.id, true, {
                                        fileName: "<[project]/src/components/screen/OrderTable/OrderTable.tsx>",
                                        lineNumber: 200,
                                        columnNumber: 37
                                    }, this)) : /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$TableRow$2f$TableRow$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__TableRow$7d$__["TableRow"], {
                                    children: /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$TableCell$2f$TableCell$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__TableCell$7d$__["TableCell"], {
                                        colSpan: 7,
                                        align: "center",
                                        children: "Нет данных"
                                    }, void 0, false, {
                                        fileName: "<[project]/src/components/screen/OrderTable/OrderTable.tsx>",
                                        lineNumber: 213,
                                        columnNumber: 37
                                    }, this)
                                }, void 0, false, {
                                    fileName: "<[project]/src/components/screen/OrderTable/OrderTable.tsx>",
                                    lineNumber: 212,
                                    columnNumber: 33
                                }, this)
                            }, void 0, false, {
                                fileName: "<[project]/src/components/screen/OrderTable/OrderTable.tsx>",
                                lineNumber: 197,
                                columnNumber: 25
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "<[project]/src/components/screen/OrderTable/OrderTable.tsx>",
                        lineNumber: 185,
                        columnNumber: 21
                    }, this)
                }, void 0, false, {
                    fileName: "<[project]/src/components/screen/OrderTable/OrderTable.tsx>",
                    lineNumber: 184,
                    columnNumber: 17
                }, this)
            }, void 0, false, {
                fileName: "<[project]/src/components/screen/OrderTable/OrderTable.tsx>",
                lineNumber: 183,
                columnNumber: 13
            }, this),
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$tablePagitaion$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["renderPagination"](currentPage, total, pageSize, handleChangePage),
            /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$Dialog$2f$Dialog$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__Dialog$7d$__["Dialog"], {
                open: openModal,
                onClose: ()=>setOpenModal(false),
                "aria-labelledby": "form-dialog-title",
                children: [
                    /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$DialogTitle$2f$DialogTitle$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__DialogTitle$7d$__["DialogTitle"], {
                        id: "form-dialog-title",
                        children: "Фильтр"
                    }, void 0, false, {
                        fileName: "<[project]/src/components/screen/OrderTable/OrderTable.tsx>",
                        lineNumber: 224,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$DialogContent$2f$DialogContent$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__DialogContent$7d$__["DialogContent"], {
                        children: /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("div", {
                            className: "mx-5 gap-5",
                            children: [
                                /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__TextField$7d$__["TextField"], {
                                    label: "Автомобиль",
                                    value: carFilter,
                                    onChange: handleCarFilterChange,
                                    className: "w-full"
                                }, void 0, false, {
                                    fileName: "<[project]/src/components/screen/OrderTable/OrderTable.tsx>",
                                    lineNumber: 227,
                                    columnNumber: 25
                                }, this),
                                /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__TextField$7d$__["TextField"], {
                                    select: true,
                                    label: "Статус",
                                    value: statusFilter,
                                    onChange: handleStatusFilterChange,
                                    className: "w-full",
                                    children: [
                                        /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$MenuItem$2f$MenuItem$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__MenuItem$7d$__["MenuItem"], {
                                            value: "",
                                            children: "Все"
                                        }, void 0, false, {
                                            fileName: "<[project]/src/components/screen/OrderTable/OrderTable.tsx>",
                                            lineNumber: 241,
                                            columnNumber: 29
                                        }, this),
                                        /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$MenuItem$2f$MenuItem$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__MenuItem$7d$__["MenuItem"], {
                                            value: "-4",
                                            children: "Отменён клиентом"
                                        }, void 0, false, {
                                            fileName: "<[project]/src/components/screen/OrderTable/OrderTable.tsx>",
                                            lineNumber: 242,
                                            columnNumber: 29
                                        }, this),
                                        /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$MenuItem$2f$MenuItem$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__MenuItem$7d$__["MenuItem"], {
                                            value: "-3",
                                            children: "Отменён поддержкой сервиса"
                                        }, void 0, false, {
                                            fileName: "<[project]/src/components/screen/OrderTable/OrderTable.tsx>",
                                            lineNumber: 243,
                                            columnNumber: 29
                                        }, this),
                                        /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$MenuItem$2f$MenuItem$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__MenuItem$7d$__["MenuItem"], {
                                            value: "-2",
                                            children: "Отменён курьером"
                                        }, void 0, false, {
                                            fileName: "<[project]/src/components/screen/OrderTable/OrderTable.tsx>",
                                            lineNumber: 244,
                                            columnNumber: 29
                                        }, this),
                                        /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$MenuItem$2f$MenuItem$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__MenuItem$7d$__["MenuItem"], {
                                            value: "-1",
                                            children: "Отменён заведением"
                                        }, void 0, false, {
                                            fileName: "<[project]/src/components/screen/OrderTable/OrderTable.tsx>",
                                            lineNumber: 245,
                                            columnNumber: 29
                                        }, this),
                                        /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$MenuItem$2f$MenuItem$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__MenuItem$7d$__["MenuItem"], {
                                            value: "0",
                                            children: "Опубликован"
                                        }, void 0, false, {
                                            fileName: "<[project]/src/components/screen/OrderTable/OrderTable.tsx>",
                                            lineNumber: 246,
                                            columnNumber: 29
                                        }, this),
                                        /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$MenuItem$2f$MenuItem$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__MenuItem$7d$__["MenuItem"], {
                                            value: "1",
                                            children: "Курьер на пути к точке А"
                                        }, void 0, false, {
                                            fileName: "<[project]/src/components/screen/OrderTable/OrderTable.tsx>",
                                            lineNumber: 247,
                                            columnNumber: 29
                                        }, this),
                                        /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$MenuItem$2f$MenuItem$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__MenuItem$7d$__["MenuItem"], {
                                            value: "2",
                                            children: "Курьер в точке А"
                                        }, void 0, false, {
                                            fileName: "<[project]/src/components/screen/OrderTable/OrderTable.tsx>",
                                            lineNumber: 248,
                                            columnNumber: 29
                                        }, this),
                                        /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$MenuItem$2f$MenuItem$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__MenuItem$7d$__["MenuItem"], {
                                            value: "3",
                                            children: "Забран, на пути в точку Б"
                                        }, void 0, false, {
                                            fileName: "<[project]/src/components/screen/OrderTable/OrderTable.tsx>",
                                            lineNumber: 249,
                                            columnNumber: 29
                                        }, this),
                                        /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$MenuItem$2f$MenuItem$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__MenuItem$7d$__["MenuItem"], {
                                            value: "4",
                                            children: "Курьер в точке Б"
                                        }, void 0, false, {
                                            fileName: "<[project]/src/components/screen/OrderTable/OrderTable.tsx>",
                                            lineNumber: 250,
                                            columnNumber: 29
                                        }, this),
                                        /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$MenuItem$2f$MenuItem$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__MenuItem$7d$__["MenuItem"], {
                                            value: "5",
                                            children: "Отработан"
                                        }, void 0, false, {
                                            fileName: "<[project]/src/components/screen/OrderTable/OrderTable.tsx>",
                                            lineNumber: 251,
                                            columnNumber: 29
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "<[project]/src/components/screen/OrderTable/OrderTable.tsx>",
                                    lineNumber: 234,
                                    columnNumber: 25
                                }, this),
                                /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("div", {
                                    className: "mt-5"
                                }, void 0, false, {
                                    fileName: "<[project]/src/components/screen/OrderTable/OrderTable.tsx>",
                                    lineNumber: 253,
                                    columnNumber: 25
                                }, this),
                                /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__TextField$7d$__["TextField"], {
                                    select: true,
                                    label: "Категория",
                                    value: categoryFilter,
                                    onChange: handleCategoryFilterChange,
                                    className: "w-full",
                                    InputLabelProps: {
                                        shrink: true
                                    },
                                    children: [
                                        /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$MenuItem$2f$MenuItem$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__MenuItem$7d$__["MenuItem"], {
                                            value: "",
                                            children: "Все"
                                        }, void 0, false, {
                                            fileName: "<[project]/src/components/screen/OrderTable/OrderTable.tsx>",
                                            lineNumber: 264,
                                            columnNumber: 29
                                        }, this),
                                        /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$MenuItem$2f$MenuItem$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__MenuItem$7d$__["MenuItem"], {
                                            value: "food",
                                            children: "Еда"
                                        }, void 0, false, {
                                            fileName: "<[project]/src/components/screen/OrderTable/OrderTable.tsx>",
                                            lineNumber: 265,
                                            columnNumber: 29
                                        }, this),
                                        /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$MenuItem$2f$MenuItem$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__MenuItem$7d$__["MenuItem"], {
                                            value: "product",
                                            children: "Товар"
                                        }, void 0, false, {
                                            fileName: "<[project]/src/components/screen/OrderTable/OrderTable.tsx>",
                                            lineNumber: 266,
                                            columnNumber: 29
                                        }, this),
                                        /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$MenuItem$2f$MenuItem$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__MenuItem$7d$__["MenuItem"], {
                                            value: "package",
                                            children: "Посылка"
                                        }, void 0, false, {
                                            fileName: "<[project]/src/components/screen/OrderTable/OrderTable.tsx>",
                                            lineNumber: 267,
                                            columnNumber: 29
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "<[project]/src/components/screen/OrderTable/OrderTable.tsx>",
                                    lineNumber: 254,
                                    columnNumber: 25
                                }, this),
                                /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("div", {
                                    className: "mt-5"
                                }, void 0, false, {
                                    fileName: "<[project]/src/components/screen/OrderTable/OrderTable.tsx>",
                                    lineNumber: 269,
                                    columnNumber: 25
                                }, this),
                                /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__TextField$7d$__["TextField"], {
                                    type: "date",
                                    label: "Начальная дата завершения",
                                    name: "startDate",
                                    value: dateFilter.startDate,
                                    onChange: handleDateFilterChange,
                                    className: "mt-10 w-full",
                                    InputLabelProps: {
                                        shrink: true
                                    }
                                }, void 0, false, {
                                    fileName: "<[project]/src/components/screen/OrderTable/OrderTable.tsx>",
                                    lineNumber: 270,
                                    columnNumber: 25
                                }, this),
                                /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("div", {
                                    className: "mt-5"
                                }, void 0, false, {
                                    fileName: "<[project]/src/components/screen/OrderTable/OrderTable.tsx>",
                                    lineNumber: 281,
                                    columnNumber: 25
                                }, this),
                                /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__TextField$7d$__["TextField"], {
                                    type: "date",
                                    label: "Конечная дата завершения",
                                    name: "endDate",
                                    value: dateFilter.endDate,
                                    onChange: handleDateFilterChange,
                                    className: "w-full",
                                    InputLabelProps: {
                                        shrink: true
                                    }
                                }, void 0, false, {
                                    fileName: "<[project]/src/components/screen/OrderTable/OrderTable.tsx>",
                                    lineNumber: 282,
                                    columnNumber: 25
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "<[project]/src/components/screen/OrderTable/OrderTable.tsx>",
                            lineNumber: 226,
                            columnNumber: 21
                        }, this)
                    }, void 0, false, {
                        fileName: "<[project]/src/components/screen/OrderTable/OrderTable.tsx>",
                        lineNumber: 225,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$DialogActions$2f$DialogActions$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__DialogActions$7d$__["DialogActions"], {
                        children: /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("div", {
                            className: "flex flex-col sm:flex-row sm:gap-5 flex-wrap",
                            children: [
                                /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("button", {
                                    className: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$genetal$2d$css$2f$general$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].BaseButton} ${!isFilterApplied ? 'hidden' : ''}`,
                                    onClick: handleResetFilter,
                                    children: "Сбросить фильтр"
                                }, void 0, false, {
                                    fileName: "<[project]/src/components/screen/OrderTable/OrderTable.tsx>",
                                    lineNumber: 297,
                                    columnNumber: 25
                                }, this),
                                /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("button", {
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$genetal$2d$css$2f$general$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].BaseButton,
                                    onClick: ()=>setOpenModal(false),
                                    children: "Отменить"
                                }, void 0, false, {
                                    fileName: "<[project]/src/components/screen/OrderTable/OrderTable.tsx>",
                                    lineNumber: 305,
                                    columnNumber: 25
                                }, this),
                                /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("button", {
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$genetal$2d$css$2f$general$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].BaseButton,
                                    onClick: handleApplyFilter,
                                    children: "Применить"
                                }, void 0, false, {
                                    fileName: "<[project]/src/components/screen/OrderTable/OrderTable.tsx>",
                                    lineNumber: 308,
                                    columnNumber: 25
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "<[project]/src/components/screen/OrderTable/OrderTable.tsx>",
                            lineNumber: 296,
                            columnNumber: 21
                        }, this)
                    }, void 0, false, {
                        fileName: "<[project]/src/components/screen/OrderTable/OrderTable.tsx>",
                        lineNumber: 295,
                        columnNumber: 17
                    }, this)
                ]
            }, void 0, true, {
                fileName: "<[project]/src/components/screen/OrderTable/OrderTable.tsx>",
                lineNumber: 223,
                columnNumber: 13
            }, this)
        ]
    }, void 0, true, {
        fileName: "<[project]/src/components/screen/OrderTable/OrderTable.tsx>",
        lineNumber: 175,
        columnNumber: 9
    }, this);
};
const __TURBOPACK__default__export__ = OrderTable;

})()),
"[project]/src/services/main.service.ts [app-ssr] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_require_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, l: __turbopack_load__, j: __turbopack_dynamic__, p: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "mainService": ()=>mainService
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/axios/lib/axios.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$md5$2f$md5$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/md5/md5.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$js$2d$cookie$2f$dist$2f$js$2e$cookie$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/js-cookie/dist/js.cookie.mjs [app-ssr] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
'use client';
;
;
;
const instance = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].create({
    withCredentials: true,
    baseURL: 'http://95.154.93.88:32768/'
});
__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].interceptors.response.use((config)=>config, async (error)=>{
    const originalRequest = error.config;
    if (error?.response?.data?.answer === -1 && // Проверка значения answer
    originalRequest && !originalRequest._isRetry) {
        originalRequest._isRetry = true;
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$js$2d$cookie$2f$dist$2f$js$2e$cookie$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].remove('token');
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$js$2d$cookie$2f$dist$2f$js$2e$cookie$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].remove('agentId');
    }
    throw error;
});
const doubleMd5 = (password)=>{
    const hash1 = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$md5$2f$md5$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](password).toString();
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$md5$2f$md5$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](hash1).toString();
};
const agentId = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$js$2d$cookie$2f$dist$2f$js$2e$cookie$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].get('agentId');
const token = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$js$2d$cookie$2f$dist$2f$js$2e$cookie$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].get('token');
const mainService = {
    // @ts-ignore
    async login ({ login, password }) {
        const { data } = await instance.get(`api/?method=agent.auth&login=${login}&password=${doubleMd5(password)}`);
        return data;
    },
    async getPaymentsAgent () {
        const { data } = await instance.get(`api/?method=agent.payments&token=${token}&agentId=${agentId}`);
        return data;
    },
    async getAllDrivers ({ offset, count, idAgent }) {
        const { data } = await instance.get(`api/?method=driver.getall&token=${token}&agentId=${idAgent}&offset=${offset}&count=${count}`);
        return data;
    },
    async getAllOrders ({ offset, count, driverId }) {
        const { data } = await instance.get(`api/?method=driver.orderlist&token=${token}&driverId=${driverId}&offset=${offset}&count=${count}`);
        return data;
    },
    async gerOrderDetails ({ driverId, orderId }) {
        const { data } = await instance.get(`api/?method=driver.orderinfo&token=${token}&driverId=${driverId}&orderId=${orderId}`);
        return data;
    },
    async getDriverInfo ({ driverId }) {
        const { data } = await instance.get(`api/?method=driver.get&token=${token}&driverId=${driverId}`);
        return data;
    },
    async getCarInfo ({ driverId }) {
        const { data } = await instance.get(`api/?method=driver.cars&token=${token}&driverId=${driverId}`);
        return data;
    },
    async getDriverAnalytics ({ driverId, dateFrom, dateTo }) {
        const { data } = await instance.get(`api/?method=driver.analytics&token=${token}&driverId=${driverId}&dateFrom=${dateFrom}&dateTo=${dateTo}`);
        return data;
    },
    async getDriverTransactions ({ driverId }) {
        const { data } = await instance.get(`api/?method=driver.transactions&token=${token}&driverId=${driverId}`);
        return data;
    },
    async createNewCar (requestData, driverId) {
        const formData = new FormData();
        //@ts-ignore
        formData.append('agentId', agentId);
        //@ts-ignore
        formData.append('driverId', requestData.driverId);
        formData.append('token', token);
        formData.append('method', 'driver.car_addedit');
        //@ts-ignore
        Object.entries(requestData.requestData).forEach(([key, value])=>{
            console.log(formData);
            // @ts-ignore
            formData.append(key, value);
        });
        const { data } = await instance.post('api/?method=', formData);
        return data;
    },
    async createNewDriver ({ requestData }) {
        const modifiedRequestData = new FormData();
        //@ts-ignore
        modifiedRequestData.append('agentId', agentId);
        modifiedRequestData.append('token', token);
        modifiedRequestData.append('method', 'driver.addedit');
        Object.entries(requestData.requestData).forEach(([key, value])=>{
            console.log(modifiedRequestData);
            // @ts-ignore
            modifiedRequestData.append(key, value);
        });
        const { data } = await instance.post('api/?method=', modifiedRequestData);
        return data;
    },
    async editDriver ({ requestData, driverId }) {
        const modifiedRequestData = new FormData();
        // @ts-ignore
        modifiedRequestData.append('agentId', agentId);
        modifiedRequestData.append('token', token);
        modifiedRequestData.append('method', 'driver.addedit');
        modifiedRequestData.append('editid', requestData.driverId);
        Object.entries(requestData.requestData).forEach(([key, value])=>{
            // @ts-ignore
            modifiedRequestData.append(key, value);
        });
        const { data } = await instance.post('api/?method=', modifiedRequestData);
        return data;
    },
    async deleteDriver (driverId) {
        const modifiedRequestData = new FormData();
        // @ts-ignore
        modifiedRequestData.append('agentId', agentId);
        modifiedRequestData.append('token', token);
        modifiedRequestData.append('method', 'driver.addedit');
        // @ts-ignore
        modifiedRequestData.append('remove', 1);
        // @ts-ignore
        modifiedRequestData.append('editid', driverId.toString());
        const { data } = await instance.post('api/?method=', modifiedRequestData);
        return data;
    }
};

})()),
"[project]/src/hooks/drivers/drivers.ts [app-ssr] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_require_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, l: __turbopack_load__, j: __turbopack_dynamic__, p: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "useCreateNewCar": ()=>useCreateNewCar,
    "useCreateNewDriver": ()=>useCreateNewDriver,
    "useDeleteDriver": ()=>useDeleteDriver,
    "useEditDriver": ()=>useEditDriver,
    "useGerOrderDetail": ()=>useGerOrderDetail,
    "useGetAllDrivers": ()=>useGetAllDrivers,
    "useGetAllOrders": ()=>useGetAllOrders,
    "useGetCarInfo": ()=>useGetCarInfo,
    "useGetDriverAnalytic": ()=>useGetDriverAnalytic,
    "useGetDriverTransactions": ()=>useGetDriverTransactions,
    "useGetDriversInfo": ()=>useGetDriversInfo
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@tanstack/react-query/build/modern/useMutation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@tanstack/react-query/build/modern/useQuery.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@tanstack/react-query/build/modern/QueryClientProvider.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$main$2e$service$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/services/main.service.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$js$2d$cookie$2f$dist$2f$js$2e$cookie$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/js-cookie/dist/js.cookie.mjs [app-ssr] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
;
;
const useGetAllDrivers = (offset, count)=>{
    const queryClient = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useQueryClient"]();
    const idAgent = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$js$2d$cookie$2f$dist$2f$js$2e$cookie$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].get('agentId');
    if (!idAgent) {
        queryClient.invalidateQueries({
            queryKey: [
                'getAllDrivers'
            ]
        });
    }
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useQuery"]({
        queryKey: [
            'getAllDrivers'
        ],
        queryFn: async ()=>{
            // @ts-ignore
            return await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$main$2e$service$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["mainService"].getAllDrivers({
                offset,
                count,
                idAgent
            });
        }
    });
};
const useGetAllOrders = (offset, count, driverId)=>{
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useQuery"]({
        queryKey: [
            'getAllOrders'
        ],
        queryFn: async ()=>{
            return await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$main$2e$service$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["mainService"].getAllOrders({
                offset,
                count,
                driverId
            });
        }
    });
};
const useGetDriversInfo = (driverId)=>{
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useQuery"]({
        queryKey: [
            'getDriverInfo'
        ],
        queryFn: async ()=>{
            return await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$main$2e$service$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["mainService"].getDriverInfo({
                driverId
            });
        }
    });
};
const useGetDriverAnalytic = (driverId, dateFrom, dateTo, enabled)=>{
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useQuery"]({
        queryKey: [
            'getDriversAnalytic'
        ],
        queryFn: async ()=>{
            return await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$main$2e$service$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["mainService"].getDriverAnalytics({
                driverId,
                dateFrom,
                dateTo
            });
        },
        enabled: enabled
    });
};
const useGerOrderDetail = (driverId, orderId)=>{
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useQuery"]({
        queryKey: [
            'gerOrderDetail'
        ],
        queryFn: async ()=>{
            return await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$main$2e$service$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["mainService"].gerOrderDetails({
                driverId,
                orderId
            });
        }
    });
};
const useGetDriverTransactions = (driverId)=>{
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useQuery"]({
        queryKey: [
            'пetDriverTransactions'
        ],
        queryFn: async ()=>{
            return await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$main$2e$service$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["mainService"].getDriverTransactions({
                driverId
            });
        },
        refetchOnMount: true,
        refetchOnWindowFocus: true
    });
};
const useGetCarInfo = (driverId)=>{
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useQuery"]({
        queryKey: [
            'getCarInfo'
        ],
        queryFn: async ()=>{
            // @ts-ignore
            return await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$main$2e$service$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["mainService"].getCarInfo({
                driverId
            });
        }
    });
};
const useEditDriver = (setRequestErrors, setEditDriverLoading)=>{
    const queryClient = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useQueryClient"]();
    const createNewDriver = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMutation"]({
        mutationKey: [
            'editDriver'
        ],
        // @ts-ignore
        mutationFn: (requestData, driverId)=>{
            setEditDriverLoading(true);
            return __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$main$2e$service$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["mainService"].editDriver({
                requestData,
                driverId
            });
        },
        onSuccess: ()=>{
            setEditDriverLoading(false);
            queryClient.invalidateQueries({
                queryKey: [
                    'getAllDrivers'
                ]
            });
        },
        onError: (error)=>{
            setRequestErrors(error);
            console.log(error);
        }
    });
    const handleCreateEditDriver = (requestData, driverId)=>{
        // @ts-ignore
        createNewDriver.mutate({
            requestData,
            driverId
        });
    };
    return handleCreateEditDriver;
};
const useCreateNewDriver = (setRequestErrors, setCreateNewDriverLoading)=>{
    const queryClient = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useQueryClient"]();
    const createNewDriver = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMutation"]({
        mutationKey: [
            'createNewDriver'
        ],
        // @ts-ignore
        mutationFn: (requestData)=>{
            setCreateNewDriverLoading(true);
            return __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$main$2e$service$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["mainService"].createNewDriver({
                requestData
            });
        },
        onSuccess: ()=>{
            setCreateNewDriverLoading(false);
            queryClient.invalidateQueries({
                queryKey: [
                    'getAllDrivers'
                ]
            });
        },
        onError: (error)=>{
            setRequestErrors(error);
            console.log(error);
        }
    });
    const handleCreateDriver = (requestData)=>{
        // @ts-ignore
        createNewDriver.mutate({
            requestData
        });
    };
    return handleCreateDriver;
};
const useCreateNewCar = (setRequestErrors)=>{
    const queryClient = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useQueryClient"]();
    const createNewCar = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMutation"]({
        mutationKey: [
            'createNewCar'
        ],
        // @ts-ignore
        mutationFn: (requestData, driverId)=>{
            return __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$main$2e$service$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["mainService"].createNewCar(requestData, driverId);
        },
        onSuccess: ()=>{
            queryClient.invalidateQueries({
                queryKey: [
                    'getCarInfo'
                ]
            });
        },
        onError: (error)=>{
            setRequestErrors(error);
            console.log(error);
        }
    });
    const handleCreateNewCar = (requestData, driverId)=>{
        // @ts-ignore
        createNewCar.mutate({
            requestData,
            driverId
        });
    };
    return handleCreateNewCar;
};
const useDeleteDriver = ()=>{
    const queryClient = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useQueryClient"]();
    const deleteDriverMutation = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMutation"]({
        mutationKey: [
            'deleteDriver'
        ],
        // @ts-ignore
        mutationFn: (driverId)=>{
            return __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$main$2e$service$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["mainService"].deleteDriver(driverId);
        },
        onSuccess: ()=>{
            queryClient.invalidateQueries({
                queryKey: [
                    'getAllDrivers'
                ]
            });
        }
    });
    const handleDeleteDriver = (driverId)=>{
        // @ts-ignore
        deleteDriverMutation.mutate(driverId);
    };
    return handleDeleteDriver;
};

})()),
"[project]/src/components/Preloader/Preloader.module.css [app-ssr] (css module)": (({ r: __turbopack_require__, f: __turbopack_require_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, l: __turbopack_load__, j: __turbopack_dynamic__, p: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname }) => (() => {

__turbopack_export_value__({
  "ball624": "ball624__Preloader__86f17ebc",
  "barUp1": "barUp1__Preloader__86f17ebc",
  "barUp2": "barUp2__Preloader__86f17ebc",
  "barUp3": "barUp3__Preloader__86f17ebc",
  "barUp4": "barUp4__Preloader__86f17ebc",
  "barUp5": "barUp5__Preloader__86f17ebc",
  "loader": "loader__Preloader__86f17ebc",
  "loader__ball": "loader__ball__Preloader__86f17ebc",
  "loader__bar": "loader__bar__Preloader__86f17ebc",
});

})()),
"[project]/src/components/Preloader/Preloader.tsx [app-ssr] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_require_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, l: __turbopack_load__, j: __turbopack_dynamic__, p: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "default": ()=>__TURBOPACK__default__export__
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/server/future/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Preloader$2f$Preloader$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__ = __turbopack_import__("[project]/src/components/Preloader/Preloader.module.css [app-ssr] (css module)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
;
const Preloader = ()=>{
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("div", {
        className: "flex justify-center items-center",
        style: {
            height: '75vh'
        },
        children: /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("div", {
            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Preloader$2f$Preloader$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].loader,
            children: [
                /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Preloader$2f$Preloader$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].loader__bar
                }, void 0, false, {
                    fileName: "<[project]/src/components/Preloader/Preloader.tsx>",
                    lineNumber: 7,
                    columnNumber: 17
                }, this),
                /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Preloader$2f$Preloader$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].loader__bar
                }, void 0, false, {
                    fileName: "<[project]/src/components/Preloader/Preloader.tsx>",
                    lineNumber: 8,
                    columnNumber: 17
                }, this),
                /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Preloader$2f$Preloader$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].loader__bar
                }, void 0, false, {
                    fileName: "<[project]/src/components/Preloader/Preloader.tsx>",
                    lineNumber: 9,
                    columnNumber: 17
                }, this),
                /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Preloader$2f$Preloader$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].loader__bar
                }, void 0, false, {
                    fileName: "<[project]/src/components/Preloader/Preloader.tsx>",
                    lineNumber: 10,
                    columnNumber: 17
                }, this),
                /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Preloader$2f$Preloader$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].loader__bar
                }, void 0, false, {
                    fileName: "<[project]/src/components/Preloader/Preloader.tsx>",
                    lineNumber: 11,
                    columnNumber: 17
                }, this),
                /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Preloader$2f$Preloader$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].loader__ball
                }, void 0, false, {
                    fileName: "<[project]/src/components/Preloader/Preloader.tsx>",
                    lineNumber: 12,
                    columnNumber: 17
                }, this)
            ]
        }, void 0, true, {
            fileName: "<[project]/src/components/Preloader/Preloader.tsx>",
            lineNumber: 6,
            columnNumber: 13
        }, this)
    }, void 0, false, {
        fileName: "<[project]/src/components/Preloader/Preloader.tsx>",
        lineNumber: 5,
        columnNumber: 9
    }, this);
};
const __TURBOPACK__default__export__ = Preloader;

})()),
"[project]/src/app/drivers/[driverId]/orders/page.tsx [app-ssr] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_require_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, l: __turbopack_load__, j: __turbopack_dynamic__, p: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "default": ()=>__TURBOPACK__default__export__
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/server/future/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$screen$2f$OrderTable$2f$OrderTable$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/screen/OrderTable/OrderTable.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/navigation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$drivers$2f$drivers$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/hooks/drivers/drivers.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Preloader$2f$Preloader$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/Preloader/Preloader.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/server/future/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$js$2d$cookie$2f$dist$2f$js$2e$cookie$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/js-cookie/dist/js.cookie.mjs [app-ssr] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
'use client';
;
;
;
;
;
;
;
const DetailPage = ()=>{
    const router = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRouter"]();
    const token = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$js$2d$cookie$2f$dist$2f$js$2e$cookie$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].get('token');
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"](()=>{
        if (!token) {
            router.push('/login');
        }
    }, [
        token
    ]);
    const params = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useParams"]();
    const pageSize = 5; // Количество элементов на странице
    const [offset, setOffset] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"](0);
    // @ts-ignore
    const { data, isFetching, error } = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$drivers$2f$drivers$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useGetAllOrders"](offset, pageSize, params.driverId);
    if (!data || isFetching) {
        return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Preloader$2f$Preloader$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "<[project]/src/app/drivers/[driverId]/orders/page.tsx>",
            lineNumber: 27,
            columnNumber: 16
        }, this);
    }
    if (error) {
        return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("p", {
            className: "text-red-600",
            children: "Ошибка при получении данных"
        }, void 0, false, {
            fileName: "<[project]/src/app/drivers/[driverId]/orders/page.tsx>",
            lineNumber: 31,
            columnNumber: 16
        }, this);
    }
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("div", {
        children: /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$screen$2f$OrderTable$2f$OrderTable$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
            offset: offset,
            setOffset: setOffset,
            data: data,
            pageSize: pageSize
        }, void 0, false, {
            fileName: "<[project]/src/app/drivers/[driverId]/orders/page.tsx>",
            lineNumber: 36,
            columnNumber: 13
        }, this)
    }, void 0, false, {
        fileName: "<[project]/src/app/drivers/[driverId]/orders/page.tsx>",
        lineNumber: 35,
        columnNumber: 9
    }, this);
};
const __TURBOPACK__default__export__ = DetailPage;

})()),
"[project]/src/app/drivers/[driverId]/orders/page.tsx [app-rsc] (ecmascript, Next.js server component, client modules ssr)": (({ r: __turbopack_require__, f: __turbopack_require_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, l: __turbopack_load__, j: __turbopack_dynamic__, p: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname }) => (() => {


})()),

};

//# sourceMappingURL=src_78fbaa._.js.map