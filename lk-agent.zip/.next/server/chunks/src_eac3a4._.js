module.exports = {

"[project]/src/services/main.service.ts [app-ssr] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_require_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, l: __turbopack_load__, j: __turbopack_dynamic__, p: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "mainService": ()=>mainService
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/axios/lib/axios.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$md5$2f$md5$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/md5/md5.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$js$2d$cookie$2f$dist$2f$js$2e$cookie$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/js-cookie/dist/js.cookie.mjs [app-ssr] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
'use client';
;
;
;
const instance = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].create({
    withCredentials: true,
    baseURL: 'http://95.154.93.88:32768/'
});
__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].interceptors.response.use((config)=>config, async (error)=>{
    const originalRequest = error.config;
    if (error?.response?.data?.answer === -1 && // Проверка значения answer
    originalRequest && !originalRequest._isRetry) {
        originalRequest._isRetry = true;
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$js$2d$cookie$2f$dist$2f$js$2e$cookie$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].remove('token');
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$js$2d$cookie$2f$dist$2f$js$2e$cookie$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].remove('agentId');
    }
    throw error;
});
const doubleMd5 = (password)=>{
    const hash1 = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$md5$2f$md5$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](password).toString();
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$md5$2f$md5$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](hash1).toString();
};
const agentId = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$js$2d$cookie$2f$dist$2f$js$2e$cookie$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].get('agentId');
const token = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$js$2d$cookie$2f$dist$2f$js$2e$cookie$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].get('token');
const mainService = {
    // @ts-ignore
    async login ({ login, password }) {
        const { data } = await instance.get(`api/?method=agent.auth&login=${login}&password=${doubleMd5(password)}`);
        return data;
    },
    async getPaymentsAgent () {
        const { data } = await instance.get(`api/?method=agent.payments&token=${token}&agentId=${agentId}`);
        return data;
    },
    async getAllDrivers ({ offset, count, idAgent }) {
        const { data } = await instance.get(`api/?method=driver.getall&token=${token}&agentId=${idAgent}&offset=${offset}&count=${count}`);
        return data;
    },
    async getAllOrders ({ offset, count, driverId }) {
        const { data } = await instance.get(`api/?method=driver.orderlist&token=${token}&driverId=${driverId}&offset=${offset}&count=${count}`);
        return data;
    },
    async gerOrderDetails ({ driverId, orderId }) {
        const { data } = await instance.get(`api/?method=driver.orderinfo&token=${token}&driverId=${driverId}&orderId=${orderId}`);
        return data;
    },
    async getDriverInfo ({ driverId }) {
        const { data } = await instance.get(`api/?method=driver.get&token=${token}&driverId=${driverId}`);
        return data;
    },
    async getCarInfo ({ driverId }) {
        const { data } = await instance.get(`api/?method=driver.cars&token=${token}&driverId=${driverId}`);
        return data;
    },
    async getDriverAnalytics ({ driverId, dateFrom, dateTo }) {
        const { data } = await instance.get(`api/?method=driver.analytics&token=${token}&driverId=${driverId}&dateFrom=${dateFrom}&dateTo=${dateTo}`);
        return data;
    },
    async getDriverTransactions ({ driverId }) {
        const { data } = await instance.get(`api/?method=driver.transactions&token=${token}&driverId=${driverId}`);
        return data;
    },
    async createNewCar (requestData, driverId) {
        const formData = new FormData();
        //@ts-ignore
        formData.append('agentId', agentId);
        //@ts-ignore
        formData.append('driverId', requestData.driverId);
        formData.append('token', token);
        formData.append('method', 'driver.car_addedit');
        //@ts-ignore
        Object.entries(requestData.requestData).forEach(([key, value])=>{
            console.log(formData);
            // @ts-ignore
            formData.append(key, value);
        });
        const { data } = await instance.post('api/?method=', formData);
        return data;
    },
    async createNewDriver ({ requestData }) {
        const modifiedRequestData = new FormData();
        //@ts-ignore
        modifiedRequestData.append('agentId', agentId);
        modifiedRequestData.append('token', token);
        modifiedRequestData.append('method', 'driver.addedit');
        Object.entries(requestData.requestData).forEach(([key, value])=>{
            console.log(modifiedRequestData);
            // @ts-ignore
            modifiedRequestData.append(key, value);
        });
        const { data } = await instance.post('api/?method=', modifiedRequestData);
        return data;
    },
    async editDriver ({ requestData, driverId }) {
        const modifiedRequestData = new FormData();
        // @ts-ignore
        modifiedRequestData.append('agentId', agentId);
        modifiedRequestData.append('token', token);
        modifiedRequestData.append('method', 'driver.addedit');
        modifiedRequestData.append('editid', requestData.driverId);
        Object.entries(requestData.requestData).forEach(([key, value])=>{
            // @ts-ignore
            modifiedRequestData.append(key, value);
        });
        const { data } = await instance.post('api/?method=', modifiedRequestData);
        return data;
    },
    async deleteDriver (driverId) {
        const modifiedRequestData = new FormData();
        // @ts-ignore
        modifiedRequestData.append('agentId', agentId);
        modifiedRequestData.append('token', token);
        modifiedRequestData.append('method', 'driver.addedit');
        // @ts-ignore
        modifiedRequestData.append('remove', 1);
        // @ts-ignore
        modifiedRequestData.append('editid', driverId.toString());
        const { data } = await instance.post('api/?method=', modifiedRequestData);
        return data;
    }
};

})()),
"[project]/src/hooks/login/login.ts [app-ssr] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_require_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, l: __turbopack_load__, j: __turbopack_dynamic__, p: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "LoginMutation": ()=>LoginMutation
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@tanstack/react-query/build/modern/useMutation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$main$2e$service$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/services/main.service.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$redux$2f$dist$2f$react$2d$redux$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/react-redux/dist/react-redux.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/navigation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$js$2d$cookie$2f$dist$2f$js$2e$cookie$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/js-cookie/dist/js.cookie.mjs [app-ssr] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
"use client";
;
;
;
;
;
const LoginMutation = (setRequestErrors)=>{
    const dispatch = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$redux$2f$dist$2f$react$2d$redux$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useDispatch"]();
    const router = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRouter"]();
    const Login = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMutation"]({
        mutationKey: [
            'login'
        ],
        mutationFn: ({ password, login })=>{
            return __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$main$2e$service$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["mainService"].login({
                password,
                login
            });
        },
        onSuccess: (data)=>{
            setRequestErrors(data.answer);
            const { agentId, token } = data;
            if (data.answer === '0') {
                __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$js$2d$cookie$2f$dist$2f$js$2e$cookie$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].set('token', token);
                __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$js$2d$cookie$2f$dist$2f$js$2e$cookie$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].set('agentId', String(agentId));
                router.push('/');
            }
        },
        onError: (error)=>{
            console.log(error);
        }
    });
    // @ts-ignore
    const handleLogin = ({ password, login })=>{
        // @ts-ignore
        Login.mutate({
            password,
            login
        });
    };
    return handleLogin;
};

})()),
"[project]/src/components/screen/Login/Login.tsx [app-ssr] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_require_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, l: __turbopack_load__, j: __turbopack_dynamic__, p: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "default": ()=>__TURBOPACK__default__export__
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/server/future/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$hook$2d$form$2f$dist$2f$index$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/react-hook-form/dist/index.esm.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/server/future/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$login$2f$login$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/hooks/login/login.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$genetal$2d$css$2f$general$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__ = __turbopack_import__("[project]/src/components/ui/genetal-css/general.module.css [app-ssr] (css module)");
"__TURBOPACK__ecmascript__hoisting__location__";
'use client';
;
;
;
;
;
const LoginForm = ()=>{
    const { register, handleSubmit, formState: { errors } } = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$hook$2d$form$2f$dist$2f$index$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useForm"]();
    const [requestErrors, setRequestErrors] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"](null);
    const handleLogin = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$login$2f$login$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["LoginMutation"](setRequestErrors);
    const onSubmit = (data)=>{
        const { password, login } = data;
        handleLogin({
            login,
            password
        });
    };
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("div", {
        className: "flex justify-center items-center h-screen",
        children: /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("div", {
            className: "bg-white p-10 rounded shadow-md w-96",
            children: [
                /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("h2", {
                    className: "text-2xl font-bold mb-5",
                    children: "Авторизация"
                }, void 0, false, {
                    fileName: "<[project]/src/components/screen/Login/Login.tsx>",
                    lineNumber: 30,
                    columnNumber: 17
                }, this),
                /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("form", {
                    className: "space-y-4",
                    onSubmit: handleSubmit(onSubmit),
                    children: [
                        /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("div", {
                            children: [
                                /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("label", {
                                    htmlFor: "login",
                                    className: "block text-gray-600",
                                    children: "Логин"
                                }, void 0, false, {
                                    fileName: "<[project]/src/components/screen/Login/Login.tsx>",
                                    lineNumber: 33,
                                    columnNumber: 25
                                }, this),
                                /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("input", {
                                    type: "text",
                                    id: "login",
                                    className: "w-full border rounded-md py-2 px-3 text-gray-700 mt-1 focus:outline-none focus:border-3 focus:border-emerald-600",
                                    ...register("login", {
                                        required: true
                                    })
                                }, void 0, false, {
                                    fileName: "<[project]/src/components/screen/Login/Login.tsx>",
                                    lineNumber: 34,
                                    columnNumber: 25
                                }, this),
                                errors.login && /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("span", {
                                    className: "text-red-600",
                                    children: "Это поле обязательное для заполнения"
                                }, void 0, false, {
                                    fileName: "<[project]/src/components/screen/Login/Login.tsx>",
                                    lineNumber: 38,
                                    columnNumber: 42
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "<[project]/src/components/screen/Login/Login.tsx>",
                            lineNumber: 32,
                            columnNumber: 21
                        }, this),
                        /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("div", {
                            children: [
                                /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("label", {
                                    htmlFor: "password",
                                    className: "block text-gray-600",
                                    children: "Пароль"
                                }, void 0, false, {
                                    fileName: "<[project]/src/components/screen/Login/Login.tsx>",
                                    lineNumber: 42,
                                    columnNumber: 25
                                }, this),
                                /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("input", {
                                    type: "password",
                                    id: "password",
                                    className: "w-full border rounded-md py-2 px-3 text-gray-700 mt-1 focus:outline-none focus:border-3 focus:border-emerald-600",
                                    ...register("password", {
                                        required: true
                                    })
                                }, void 0, false, {
                                    fileName: "<[project]/src/components/screen/Login/Login.tsx>",
                                    lineNumber: 43,
                                    columnNumber: 25
                                }, this),
                                errors.password && /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("span", {
                                    className: "text-red-600",
                                    children: "Это поле обязательное для заполнения"
                                }, void 0, false, {
                                    fileName: "<[project]/src/components/screen/Login/Login.tsx>",
                                    lineNumber: 47,
                                    columnNumber: 45
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "<[project]/src/components/screen/Login/Login.tsx>",
                            lineNumber: 41,
                            columnNumber: 21
                        }, this),
                        /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("span", {
                            className: "text-red-600 text-lg",
                            children: requestErrors && requestErrors === '1' && 'не все аргументы заполнены' || requestErrors === '2' && 'пара логин-пароль неверная'
                        }, void 0, false, {
                            fileName: "<[project]/src/components/screen/Login/Login.tsx>",
                            lineNumber: 49,
                            columnNumber: 21
                        }, this),
                        /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("button", {
                            type: "submit",
                            className: `w-full ${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$genetal$2d$css$2f$general$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].BaseButton}`,
                            children: "Войти"
                        }, void 0, false, {
                            fileName: "<[project]/src/components/screen/Login/Login.tsx>",
                            lineNumber: 50,
                            columnNumber: 21
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "<[project]/src/components/screen/Login/Login.tsx>",
                    lineNumber: 31,
                    columnNumber: 17
                }, this)
            ]
        }, void 0, true, {
            fileName: "<[project]/src/components/screen/Login/Login.tsx>",
            lineNumber: 29,
            columnNumber: 13
        }, this)
    }, void 0, false, {
        fileName: "<[project]/src/components/screen/Login/Login.tsx>",
        lineNumber: 28,
        columnNumber: 9
    }, this);
};
const __TURBOPACK__default__export__ = LoginForm;

})()),
"[project]/src/app/login/page.tsx [app-rsc] (ecmascript, Next.js server component, client modules ssr)": (({ r: __turbopack_require__, f: __turbopack_require_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, l: __turbopack_load__, j: __turbopack_dynamic__, p: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname }) => (() => {


})()),

};

//# sourceMappingURL=src_eac3a4._.js.map