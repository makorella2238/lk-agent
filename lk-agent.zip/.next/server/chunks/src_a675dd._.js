module.exports = {

"[project]/src/utils/formateData.ts [app-ssr] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_require_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, l: __turbopack_load__, j: __turbopack_dynamic__, p: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "formatDate": ()=>formatDate,
    "formatDateAndClock": ()=>formatDateAndClock,
    "formatPrice": ()=>formatPrice
});
const formatDateAndClock = (date)=>{
    const reverseDate = date.split('T');
    const fistNewDate = reverseDate[0].split('-').reverse().join('.');
    return fistNewDate + ' ' + reverseDate[1];
};
const formatDate = (date)=>{
    return date.split('T')[0].split('-').reverse().join('.');
};
const formatPrice = (price)=>{
    const newPrice = price.toFixed(2).replace('.', ',');
    return `${newPrice} ₽`;
};

})()),
"[project]/src/components/screen/Transaction/Transaction.tsx [app-ssr] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_require_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, l: __turbopack_load__, j: __turbopack_dynamic__, p: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "default": ()=>__TURBOPACK__default__export__
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/server/future/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$Table$2f$Table$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@material-ui/core/esm/Table/Table.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$TableBody$2f$TableBody$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@material-ui/core/esm/TableBody/TableBody.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$TableCell$2f$TableCell$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@material-ui/core/esm/TableCell/TableCell.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$TableContainer$2f$TableContainer$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@material-ui/core/esm/TableContainer/TableContainer.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$TableHead$2f$TableHead$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@material-ui/core/esm/TableHead/TableHead.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$TableRow$2f$TableRow$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@material-ui/core/esm/TableRow/TableRow.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$Paper$2f$Paper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@material-ui/core/esm/Paper/Paper.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$formateData$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/utils/formateData.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$genetal$2d$css$2f$general$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__ = __turbopack_import__("[project]/src/components/ui/genetal-css/general.module.css [app-ssr] (css module)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/image.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/navigation.js [app-ssr] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
'use client';
;
;
;
;
;
;
;
;
;
;
;
;
const Transactions = ({ data })=>{
    const router = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRouter"]();
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("div", {
        className: "container mx-auto relative",
        children: [
            /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("div", {
                className: `absolute top-0.5 left-0.5 ${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$genetal$2d$css$2f$general$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].BaseButton} p-2 flex ml-5 transition-colors `,
                onClick: ()=>router.back(),
                children: [
                    /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                        className: "sm:mr-3",
                        src: "/arrow_back.svg",
                        alt: "arrow_back",
                        width: 20,
                        height: 20
                    }, void 0, false, {
                        fileName: "<[project]/src/components/screen/Transaction/Transaction.tsx>",
                        lineNumber: 27,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("p", {
                        className: "hidden sm:block",
                        children: "Назад"
                    }, void 0, false, {
                        fileName: "<[project]/src/components/screen/Transaction/Transaction.tsx>",
                        lineNumber: 28,
                        columnNumber: 17
                    }, this)
                ]
            }, void 0, true, {
                fileName: "<[project]/src/components/screen/Transaction/Transaction.tsx>",
                lineNumber: 25,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("h2", {
                className: "ml-2 text-2xl font-bold mb-3 sm:mb-6 text-center",
                children: "История баланса"
            }, void 0, false, {
                fileName: "<[project]/src/components/screen/Transaction/Transaction.tsx>",
                lineNumber: 30,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$TableContainer$2f$TableContainer$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                component: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$Paper$2f$Paper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
                children: /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$Table$2f$Table$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                    "aria-label": "balance history table",
                    children: [
                        /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$TableHead$2f$TableHead$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                            children: /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$TableRow$2f$TableRow$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                children: [
                                    /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$TableCell$2f$TableCell$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                        children: "Дата и время"
                                    }, void 0, false, {
                                        fileName: "<[project]/src/components/screen/Transaction/Transaction.tsx>",
                                        lineNumber: 35,
                                        columnNumber: 29
                                    }, this),
                                    /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$TableCell$2f$TableCell$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                        children: "Баланс"
                                    }, void 0, false, {
                                        fileName: "<[project]/src/components/screen/Transaction/Transaction.tsx>",
                                        lineNumber: 36,
                                        columnNumber: 29
                                    }, this),
                                    /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$TableCell$2f$TableCell$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                        children: "Изменение"
                                    }, void 0, false, {
                                        fileName: "<[project]/src/components/screen/Transaction/Transaction.tsx>",
                                        lineNumber: 37,
                                        columnNumber: 29
                                    }, this),
                                    /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$TableCell$2f$TableCell$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                        children: "Описание"
                                    }, void 0, false, {
                                        fileName: "<[project]/src/components/screen/Transaction/Transaction.tsx>",
                                        lineNumber: 38,
                                        columnNumber: 29
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "<[project]/src/components/screen/Transaction/Transaction.tsx>",
                                lineNumber: 34,
                                columnNumber: 25
                            }, this)
                        }, void 0, false, {
                            fileName: "<[project]/src/components/screen/Transaction/Transaction.tsx>",
                            lineNumber: 33,
                            columnNumber: 21
                        }, this),
                        /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$TableBody$2f$TableBody$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                            children: data.transactions.map((transaction)=>/*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$TableRow$2f$TableRow$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                    children: [
                                        /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$TableCell$2f$TableCell$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                            children: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$formateData$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["formatDateAndClock"](transaction.dateTime)
                                        }, void 0, false, {
                                            fileName: "<[project]/src/components/screen/Transaction/Transaction.tsx>",
                                            lineNumber: 44,
                                            columnNumber: 33
                                        }, this),
                                        /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$TableCell$2f$TableCell$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                            children: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$formateData$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["formatPrice"](transaction.balance)
                                        }, void 0, false, {
                                            fileName: "<[project]/src/components/screen/Transaction/Transaction.tsx>",
                                            lineNumber: 45,
                                            columnNumber: 33
                                        }, this),
                                        /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$TableCell$2f$TableCell$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                            children: [
                                                transaction.delta > 0 ? '+' : '',
                                                __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$formateData$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["formatPrice"](transaction.delta)
                                            ]
                                        }, void 0, true, {
                                            fileName: "<[project]/src/components/screen/Transaction/Transaction.tsx>",
                                            lineNumber: 46,
                                            columnNumber: 33
                                        }, this),
                                        /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$TableCell$2f$TableCell$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                            children: transaction.description
                                        }, void 0, false, {
                                            fileName: "<[project]/src/components/screen/Transaction/Transaction.tsx>",
                                            lineNumber: 50,
                                            columnNumber: 33
                                        }, this)
                                    ]
                                }, transaction.id, true, {
                                    fileName: "<[project]/src/components/screen/Transaction/Transaction.tsx>",
                                    lineNumber: 43,
                                    columnNumber: 29
                                }, this))
                        }, void 0, false, {
                            fileName: "<[project]/src/components/screen/Transaction/Transaction.tsx>",
                            lineNumber: 41,
                            columnNumber: 21
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "<[project]/src/components/screen/Transaction/Transaction.tsx>",
                    lineNumber: 32,
                    columnNumber: 17
                }, this)
            }, void 0, false, {
                fileName: "<[project]/src/components/screen/Transaction/Transaction.tsx>",
                lineNumber: 31,
                columnNumber: 13
            }, this)
        ]
    }, void 0, true, {
        fileName: "<[project]/src/components/screen/Transaction/Transaction.tsx>",
        lineNumber: 24,
        columnNumber: 9
    }, this);
};
const __TURBOPACK__default__export__ = Transactions;

})()),
"[project]/src/services/main.service.ts [app-ssr] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_require_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, l: __turbopack_load__, j: __turbopack_dynamic__, p: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "mainService": ()=>mainService
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/axios/lib/axios.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$md5$2f$md5$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/md5/md5.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$js$2d$cookie$2f$dist$2f$js$2e$cookie$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/js-cookie/dist/js.cookie.mjs [app-ssr] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
'use client';
;
;
;
const instance = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].create({
    withCredentials: true,
    baseURL: 'http://95.154.93.88:32768/'
});
__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].interceptors.response.use((config)=>config, async (error)=>{
    const originalRequest = error.config;
    if (error?.response?.data?.answer === -1 && // Проверка значения answer
    originalRequest && !originalRequest._isRetry) {
        originalRequest._isRetry = true;
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$js$2d$cookie$2f$dist$2f$js$2e$cookie$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].remove('token');
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$js$2d$cookie$2f$dist$2f$js$2e$cookie$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].remove('agentId');
    }
    throw error;
});
const doubleMd5 = (password)=>{
    const hash1 = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$md5$2f$md5$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](password).toString();
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$md5$2f$md5$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](hash1).toString();
};
const agentId = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$js$2d$cookie$2f$dist$2f$js$2e$cookie$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].get('agentId');
const token = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$js$2d$cookie$2f$dist$2f$js$2e$cookie$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].get('token');
const mainService = {
    // @ts-ignore
    async login ({ login, password }) {
        const { data } = await instance.get(`api/?method=agent.auth&login=${login}&password=${doubleMd5(password)}`);
        return data;
    },
    async getPaymentsAgent () {
        const { data } = await instance.get(`api/?method=agent.payments&token=${token}&agentId=${agentId}`);
        return data;
    },
    async getAllDrivers ({ offset, count, idAgent }) {
        const { data } = await instance.get(`api/?method=driver.getall&token=${token}&agentId=${idAgent}&offset=${offset}&count=${count}`);
        return data;
    },
    async getAllOrders ({ offset, count, driverId }) {
        const { data } = await instance.get(`api/?method=driver.orderlist&token=${token}&driverId=${driverId}&offset=${offset}&count=${count}`);
        return data;
    },
    async gerOrderDetails ({ driverId, orderId }) {
        const { data } = await instance.get(`api/?method=driver.orderinfo&token=${token}&driverId=${driverId}&orderId=${orderId}`);
        return data;
    },
    async getDriverInfo ({ driverId }) {
        const { data } = await instance.get(`api/?method=driver.get&token=${token}&driverId=${driverId}`);
        return data;
    },
    async getCarInfo ({ driverId }) {
        const { data } = await instance.get(`api/?method=driver.cars&token=${token}&driverId=${driverId}`);
        return data;
    },
    async getDriverAnalytics ({ driverId, dateFrom, dateTo }) {
        const { data } = await instance.get(`api/?method=driver.analytics&token=${token}&driverId=${driverId}&dateFrom=${dateFrom}&dateTo=${dateTo}`);
        return data;
    },
    async getDriverTransactions ({ driverId }) {
        const { data } = await instance.get(`api/?method=driver.transactions&token=${token}&driverId=${driverId}`);
        return data;
    },
    async createNewCar (requestData, driverId) {
        const formData = new FormData();
        //@ts-ignore
        formData.append('agentId', agentId);
        //@ts-ignore
        formData.append('driverId', requestData.driverId);
        formData.append('token', token);
        formData.append('method', 'driver.car_addedit');
        //@ts-ignore
        Object.entries(requestData.requestData).forEach(([key, value])=>{
            console.log(formData);
            // @ts-ignore
            formData.append(key, value);
        });
        const { data } = await instance.post('api/?method=', formData);
        return data;
    },
    async createNewDriver ({ requestData }) {
        const modifiedRequestData = new FormData();
        //@ts-ignore
        modifiedRequestData.append('agentId', agentId);
        modifiedRequestData.append('token', token);
        modifiedRequestData.append('method', 'driver.addedit');
        Object.entries(requestData.requestData).forEach(([key, value])=>{
            console.log(modifiedRequestData);
            // @ts-ignore
            modifiedRequestData.append(key, value);
        });
        const { data } = await instance.post('api/?method=', modifiedRequestData);
        return data;
    },
    async editDriver ({ requestData, driverId }) {
        const modifiedRequestData = new FormData();
        // @ts-ignore
        modifiedRequestData.append('agentId', agentId);
        modifiedRequestData.append('token', token);
        modifiedRequestData.append('method', 'driver.addedit');
        modifiedRequestData.append('editid', requestData.driverId);
        Object.entries(requestData.requestData).forEach(([key, value])=>{
            // @ts-ignore
            modifiedRequestData.append(key, value);
        });
        const { data } = await instance.post('api/?method=', modifiedRequestData);
        return data;
    },
    async deleteDriver (driverId) {
        const modifiedRequestData = new FormData();
        // @ts-ignore
        modifiedRequestData.append('agentId', agentId);
        modifiedRequestData.append('token', token);
        modifiedRequestData.append('method', 'driver.addedit');
        // @ts-ignore
        modifiedRequestData.append('remove', 1);
        // @ts-ignore
        modifiedRequestData.append('editid', driverId.toString());
        const { data } = await instance.post('api/?method=', modifiedRequestData);
        return data;
    }
};

})()),
"[project]/src/hooks/drivers/drivers.ts [app-ssr] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_require_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, l: __turbopack_load__, j: __turbopack_dynamic__, p: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "useCreateNewCar": ()=>useCreateNewCar,
    "useCreateNewDriver": ()=>useCreateNewDriver,
    "useDeleteDriver": ()=>useDeleteDriver,
    "useEditDriver": ()=>useEditDriver,
    "useGerOrderDetail": ()=>useGerOrderDetail,
    "useGetAllDrivers": ()=>useGetAllDrivers,
    "useGetAllOrders": ()=>useGetAllOrders,
    "useGetCarInfo": ()=>useGetCarInfo,
    "useGetDriverAnalytic": ()=>useGetDriverAnalytic,
    "useGetDriverTransactions": ()=>useGetDriverTransactions,
    "useGetDriversInfo": ()=>useGetDriversInfo
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@tanstack/react-query/build/modern/useMutation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@tanstack/react-query/build/modern/useQuery.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@tanstack/react-query/build/modern/QueryClientProvider.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$main$2e$service$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/services/main.service.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$js$2d$cookie$2f$dist$2f$js$2e$cookie$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/js-cookie/dist/js.cookie.mjs [app-ssr] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
;
;
const useGetAllDrivers = (offset, count)=>{
    const queryClient = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useQueryClient"]();
    const idAgent = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$js$2d$cookie$2f$dist$2f$js$2e$cookie$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].get('agentId');
    if (!idAgent) {
        queryClient.invalidateQueries({
            queryKey: [
                'getAllDrivers'
            ]
        });
    }
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useQuery"]({
        queryKey: [
            'getAllDrivers'
        ],
        queryFn: async ()=>{
            // @ts-ignore
            return await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$main$2e$service$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["mainService"].getAllDrivers({
                offset,
                count,
                idAgent
            });
        }
    });
};
const useGetAllOrders = (offset, count, driverId)=>{
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useQuery"]({
        queryKey: [
            'getAllOrders'
        ],
        queryFn: async ()=>{
            return await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$main$2e$service$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["mainService"].getAllOrders({
                offset,
                count,
                driverId
            });
        }
    });
};
const useGetDriversInfo = (driverId)=>{
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useQuery"]({
        queryKey: [
            'getDriverInfo'
        ],
        queryFn: async ()=>{
            return await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$main$2e$service$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["mainService"].getDriverInfo({
                driverId
            });
        }
    });
};
const useGetDriverAnalytic = (driverId, dateFrom, dateTo, enabled)=>{
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useQuery"]({
        queryKey: [
            'getDriversAnalytic'
        ],
        queryFn: async ()=>{
            return await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$main$2e$service$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["mainService"].getDriverAnalytics({
                driverId,
                dateFrom,
                dateTo
            });
        },
        enabled: enabled
    });
};
const useGerOrderDetail = (driverId, orderId)=>{
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useQuery"]({
        queryKey: [
            'gerOrderDetail'
        ],
        queryFn: async ()=>{
            return await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$main$2e$service$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["mainService"].gerOrderDetails({
                driverId,
                orderId
            });
        }
    });
};
const useGetDriverTransactions = (driverId)=>{
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useQuery"]({
        queryKey: [
            'пetDriverTransactions'
        ],
        queryFn: async ()=>{
            return await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$main$2e$service$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["mainService"].getDriverTransactions({
                driverId
            });
        },
        refetchOnMount: true,
        refetchOnWindowFocus: true
    });
};
const useGetCarInfo = (driverId)=>{
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useQuery"]({
        queryKey: [
            'getCarInfo'
        ],
        queryFn: async ()=>{
            // @ts-ignore
            return await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$main$2e$service$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["mainService"].getCarInfo({
                driverId
            });
        }
    });
};
const useEditDriver = (setRequestErrors, setEditDriverLoading)=>{
    const queryClient = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useQueryClient"]();
    const createNewDriver = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMutation"]({
        mutationKey: [
            'editDriver'
        ],
        // @ts-ignore
        mutationFn: (requestData, driverId)=>{
            setEditDriverLoading(true);
            return __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$main$2e$service$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["mainService"].editDriver({
                requestData,
                driverId
            });
        },
        onSuccess: ()=>{
            setEditDriverLoading(false);
            queryClient.invalidateQueries({
                queryKey: [
                    'getAllDrivers'
                ]
            });
        },
        onError: (error)=>{
            setRequestErrors(error);
            console.log(error);
        }
    });
    const handleCreateEditDriver = (requestData, driverId)=>{
        // @ts-ignore
        createNewDriver.mutate({
            requestData,
            driverId
        });
    };
    return handleCreateEditDriver;
};
const useCreateNewDriver = (setRequestErrors, setCreateNewDriverLoading)=>{
    const queryClient = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useQueryClient"]();
    const createNewDriver = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMutation"]({
        mutationKey: [
            'createNewDriver'
        ],
        // @ts-ignore
        mutationFn: (requestData)=>{
            setCreateNewDriverLoading(true);
            return __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$main$2e$service$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["mainService"].createNewDriver({
                requestData
            });
        },
        onSuccess: ()=>{
            setCreateNewDriverLoading(false);
            queryClient.invalidateQueries({
                queryKey: [
                    'getAllDrivers'
                ]
            });
        },
        onError: (error)=>{
            setRequestErrors(error);
            console.log(error);
        }
    });
    const handleCreateDriver = (requestData)=>{
        // @ts-ignore
        createNewDriver.mutate({
            requestData
        });
    };
    return handleCreateDriver;
};
const useCreateNewCar = (setRequestErrors)=>{
    const queryClient = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useQueryClient"]();
    const createNewCar = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMutation"]({
        mutationKey: [
            'createNewCar'
        ],
        // @ts-ignore
        mutationFn: (requestData, driverId)=>{
            return __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$main$2e$service$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["mainService"].createNewCar(requestData, driverId);
        },
        onSuccess: ()=>{
            queryClient.invalidateQueries({
                queryKey: [
                    'getCarInfo'
                ]
            });
        },
        onError: (error)=>{
            setRequestErrors(error);
            console.log(error);
        }
    });
    const handleCreateNewCar = (requestData, driverId)=>{
        // @ts-ignore
        createNewCar.mutate({
            requestData,
            driverId
        });
    };
    return handleCreateNewCar;
};
const useDeleteDriver = ()=>{
    const queryClient = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useQueryClient"]();
    const deleteDriverMutation = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMutation"]({
        mutationKey: [
            'deleteDriver'
        ],
        // @ts-ignore
        mutationFn: (driverId)=>{
            return __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$main$2e$service$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["mainService"].deleteDriver(driverId);
        },
        onSuccess: ()=>{
            queryClient.invalidateQueries({
                queryKey: [
                    'getAllDrivers'
                ]
            });
        }
    });
    const handleDeleteDriver = (driverId)=>{
        // @ts-ignore
        deleteDriverMutation.mutate(driverId);
    };
    return handleDeleteDriver;
};

})()),
"[project]/src/components/Preloader/Preloader.module.css [app-ssr] (css module)": (({ r: __turbopack_require__, f: __turbopack_require_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, l: __turbopack_load__, j: __turbopack_dynamic__, p: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname }) => (() => {

__turbopack_export_value__({
  "ball624": "ball624__Preloader__86f17ebc",
  "barUp1": "barUp1__Preloader__86f17ebc",
  "barUp2": "barUp2__Preloader__86f17ebc",
  "barUp3": "barUp3__Preloader__86f17ebc",
  "barUp4": "barUp4__Preloader__86f17ebc",
  "barUp5": "barUp5__Preloader__86f17ebc",
  "loader": "loader__Preloader__86f17ebc",
  "loader__ball": "loader__ball__Preloader__86f17ebc",
  "loader__bar": "loader__bar__Preloader__86f17ebc",
});

})()),
"[project]/src/components/Preloader/Preloader.tsx [app-ssr] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_require_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, l: __turbopack_load__, j: __turbopack_dynamic__, p: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "default": ()=>__TURBOPACK__default__export__
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/server/future/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Preloader$2f$Preloader$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__ = __turbopack_import__("[project]/src/components/Preloader/Preloader.module.css [app-ssr] (css module)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
;
const Preloader = ()=>{
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("div", {
        className: "flex justify-center items-center",
        style: {
            height: '75vh'
        },
        children: /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("div", {
            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Preloader$2f$Preloader$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].loader,
            children: [
                /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Preloader$2f$Preloader$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].loader__bar
                }, void 0, false, {
                    fileName: "<[project]/src/components/Preloader/Preloader.tsx>",
                    lineNumber: 7,
                    columnNumber: 17
                }, this),
                /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Preloader$2f$Preloader$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].loader__bar
                }, void 0, false, {
                    fileName: "<[project]/src/components/Preloader/Preloader.tsx>",
                    lineNumber: 8,
                    columnNumber: 17
                }, this),
                /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Preloader$2f$Preloader$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].loader__bar
                }, void 0, false, {
                    fileName: "<[project]/src/components/Preloader/Preloader.tsx>",
                    lineNumber: 9,
                    columnNumber: 17
                }, this),
                /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Preloader$2f$Preloader$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].loader__bar
                }, void 0, false, {
                    fileName: "<[project]/src/components/Preloader/Preloader.tsx>",
                    lineNumber: 10,
                    columnNumber: 17
                }, this),
                /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Preloader$2f$Preloader$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].loader__bar
                }, void 0, false, {
                    fileName: "<[project]/src/components/Preloader/Preloader.tsx>",
                    lineNumber: 11,
                    columnNumber: 17
                }, this),
                /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Preloader$2f$Preloader$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].loader__ball
                }, void 0, false, {
                    fileName: "<[project]/src/components/Preloader/Preloader.tsx>",
                    lineNumber: 12,
                    columnNumber: 17
                }, this)
            ]
        }, void 0, true, {
            fileName: "<[project]/src/components/Preloader/Preloader.tsx>",
            lineNumber: 6,
            columnNumber: 13
        }, this)
    }, void 0, false, {
        fileName: "<[project]/src/components/Preloader/Preloader.tsx>",
        lineNumber: 5,
        columnNumber: 9
    }, this);
};
const __TURBOPACK__default__export__ = Preloader;

})()),
"[project]/src/app/drivers/[driverId]/transactions/page.tsx [app-ssr] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_require_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, l: __turbopack_load__, j: __turbopack_dynamic__, p: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "default": ()=>__TURBOPACK__default__export__
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/server/future/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/server/future/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$screen$2f$Transaction$2f$Transaction$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/screen/Transaction/Transaction.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/navigation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$drivers$2f$drivers$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/hooks/drivers/drivers.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Preloader$2f$Preloader$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/Preloader/Preloader.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$js$2d$cookie$2f$dist$2f$js$2e$cookie$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/js-cookie/dist/js.cookie.mjs [app-ssr] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
'use client';
;
;
;
;
;
;
;
const TransactionsPage = ()=>{
    const router = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRouter"]();
    const token = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$js$2d$cookie$2f$dist$2f$js$2e$cookie$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].get('token');
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"](()=>{
        if (!token) {
            router.push('/login');
        }
    }, [
        token
    ]);
    const params = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useParams"]();
    // @ts-ignore
    const { data, isFetching, error } = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$drivers$2f$drivers$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useGetDriverTransactions"](params.driverId);
    if (isFetching || !data) {
        return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Preloader$2f$Preloader$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "<[project]/src/app/drivers/[driverId]/transactions/page.tsx>",
            lineNumber: 26,
            columnNumber: 16
        }, this);
    }
    console.log(params.driverId);
    if (error) {
        console.log(error);
        return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("p", {
            children: "Ошибка при получении данных"
        }, void 0, false, {
            fileName: "<[project]/src/app/drivers/[driverId]/transactions/page.tsx>",
            lineNumber: 32,
            columnNumber: 16
        }, this);
    }
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("div", {
        children: /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$screen$2f$Transaction$2f$Transaction$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
            data: data
        }, void 0, false, {
            fileName: "<[project]/src/app/drivers/[driverId]/transactions/page.tsx>",
            lineNumber: 37,
            columnNumber: 13
        }, this)
    }, void 0, false, {
        fileName: "<[project]/src/app/drivers/[driverId]/transactions/page.tsx>",
        lineNumber: 36,
        columnNumber: 9
    }, this);
};
const __TURBOPACK__default__export__ = TransactionsPage;

})()),
"[project]/src/app/drivers/[driverId]/transactions/page.tsx [app-rsc] (ecmascript, Next.js server component, client modules ssr)": (({ r: __turbopack_require__, f: __turbopack_require_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, l: __turbopack_load__, j: __turbopack_dynamic__, p: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname }) => (() => {


})()),

};

//# sourceMappingURL=src_a675dd._.js.map