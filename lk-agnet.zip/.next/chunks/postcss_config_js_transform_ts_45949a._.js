(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push(["chunks/postcss_config_js_transform_ts_45949a._.js", {

"[project]/postcss.config.js/transform.ts/(CONFIG)/[project]/postcss.config.js [postcss] (ecmascript) (ecmascript, loader)": (({ r: __turbopack_require__, f: __turbopack_require_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, l: __turbopack_load__, j: __turbopack_dynamic__, p: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname }) => (() => {

__turbopack_export_value__((__turbopack_import__) => {
    return Promise.all(["chunks/postcss_config_js_transform_ts_71c0f0._.js","chunks/postcss_config_js_transform_ts_f5bd92._.js"].map((chunk) => __turbopack_load__(chunk))).then(() => {
        return __turbopack_require__("[project]/postcss.config.js/transform.ts/(CONFIG)/[project]/postcss.config.js [postcss] (ecmascript) (ecmascript, manifest chunk)");
    }).then((chunks) => {
        return Promise.all(chunks.map((chunk) => __turbopack_load__(chunk)));
    }).then(() => {
        return __turbopack_import__("[project]/postcss.config.js/transform.ts/(CONFIG)/[project]/postcss.config.js [postcss] (ecmascript) (ecmascript)");
    });
});

})()),
}]);