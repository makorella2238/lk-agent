const CHUNK_PUBLIC_PATH = "server/app/analytics/page.js";
const runtime = require("../../chunks/[turbopack]_runtime.js");
runtime.loadChunk("server/chunks/node_modules_d52280._.js");
runtime.loadChunk("server/chunks/[root of the server]__92b671._.js");
runtime.getOrInstantiateRuntimeModule("[project]/.next-internal/server/app/analytics/page/actions.js (ecmascript)", CHUNK_PUBLIC_PATH);
module.exports = runtime.getOrInstantiateRuntimeModule("[project]/node_modules/next/dist/esm/build/templates/app-page.js/(COMPONENT_0)/[project]/src/app/layout.tsx [app-rsc] (ecmascript, Next.js server component)/(COMPONENT_1)/[project]/node_modules/next/dist/client/components/not-found-error.js [app-rsc] (ecmascript, Next.js server component)/(COMPONENT_2)/[project]/src/app/analytics/page.tsx [app-rsc] (ecmascript, Next.js server component) (ecmascript) {facade}", CHUNK_PUBLIC_PATH).exports;
