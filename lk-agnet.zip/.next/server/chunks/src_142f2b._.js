module.exports = {

"[project]/src/components/Payments/Payments.module.css [app-ssr] (css module)": (({ r: __turbopack_require__, f: __turbopack_require_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, l: __turbopack_load__, j: __turbopack_dynamic__, p: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname }) => (() => {

__turbopack_export_value__({
  "border_l": "border_l__Payments__2b69c53b",
  "filter_input": "filter_input__Payments__2b69c53b",
  "modalContainer": "modalContainer__Payments__2b69c53b",
});

})()),
"[project]/src/components/ui/genetal-css/general.module.css [app-ssr] (css module)": (({ r: __turbopack_require__, f: __turbopack_require_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, l: __turbopack_load__, j: __turbopack_dynamic__, p: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname }) => (() => {

__turbopack_export_value__({
  "BaseButton": "BaseButton__general__90774c70",
  "bodyText": "bodyText__general__90774c70",
  "borderContainer": "borderContainer__general__90774c70",
  "buttonGreen": "buttonGreen__general__90774c70",
  "buttonRed": "buttonRed__general__90774c70",
  "buttonYel": "buttonYel__general__90774c70",
  "easeInOut": "easeInOut__general__90774c70",
  "fadeIn": "fadeIn__general__90774c70",
  "filter_container": "filter_container__general__90774c70",
  "filter_input": "filter_input__general__90774c70",
  "gradientText": "gradientText__general__90774c70",
  "miniBorderContainer": "miniBorderContainer__general__90774c70",
});

})()),
"[project]/src/utils/formateData.ts [app-ssr] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_require_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, l: __turbopack_load__, j: __turbopack_dynamic__, p: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "formatDate": ()=>formatDate,
    "formatDateAndClock": ()=>formatDateAndClock,
    "formatPrice": ()=>formatPrice
});
const formatDateAndClock = (date)=>{
    const reverseDate = date.split('T');
    const fistNewDate = reverseDate[0].split('-').reverse().join('.');
    return fistNewDate + ' ' + reverseDate[1];
};
const formatDate = (date)=>{
    return date.split('T')[0].split('-').reverse().join('.');
};
const formatPrice = (price)=>{
    const newPrice = price.toFixed(2).replace('.', ',');
    return `${newPrice} ₽`;
};

})()),
"[project]/src/components/Payments/Payments.tsx [app-ssr] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_require_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, l: __turbopack_load__, j: __turbopack_dynamic__, p: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "default": ()=>__TURBOPACK__default__export__
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/server/future/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/server/future/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$Dialog$2f$Dialog$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__Dialog$7d$__ = __turbopack_import__("[project]/node_modules/@material-ui/core/esm/Dialog/Dialog.js [app-ssr] (ecmascript) {export default as Dialog}");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$DialogActions$2f$DialogActions$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__DialogActions$7d$__ = __turbopack_import__("[project]/node_modules/@material-ui/core/esm/DialogActions/DialogActions.js [app-ssr] (ecmascript) {export default as DialogActions}");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$DialogContent$2f$DialogContent$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__DialogContent$7d$__ = __turbopack_import__("[project]/node_modules/@material-ui/core/esm/DialogContent/DialogContent.js [app-ssr] (ecmascript) {export default as DialogContent}");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$DialogTitle$2f$DialogTitle$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__DialogTitle$7d$__ = __turbopack_import__("[project]/node_modules/@material-ui/core/esm/DialogTitle/DialogTitle.js [app-ssr] (ecmascript) {export default as DialogTitle}");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$InputLabel$2f$InputLabel$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__InputLabel$7d$__ = __turbopack_import__("[project]/node_modules/@material-ui/core/esm/InputLabel/InputLabel.js [app-ssr] (ecmascript) {export default as InputLabel}");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$MenuItem$2f$MenuItem$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__MenuItem$7d$__ = __turbopack_import__("[project]/node_modules/@material-ui/core/esm/MenuItem/MenuItem.js [app-ssr] (ecmascript) {export default as MenuItem}");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$Paper$2f$Paper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__Paper$7d$__ = __turbopack_import__("[project]/node_modules/@material-ui/core/esm/Paper/Paper.js [app-ssr] (ecmascript) {export default as Paper}");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$Select$2f$Select$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__Select$7d$__ = __turbopack_import__("[project]/node_modules/@material-ui/core/esm/Select/Select.js [app-ssr] (ecmascript) {export default as Select}");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$Table$2f$Table$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__Table$7d$__ = __turbopack_import__("[project]/node_modules/@material-ui/core/esm/Table/Table.js [app-ssr] (ecmascript) {export default as Table}");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$TableBody$2f$TableBody$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__TableBody$7d$__ = __turbopack_import__("[project]/node_modules/@material-ui/core/esm/TableBody/TableBody.js [app-ssr] (ecmascript) {export default as TableBody}");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$TableCell$2f$TableCell$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__TableCell$7d$__ = __turbopack_import__("[project]/node_modules/@material-ui/core/esm/TableCell/TableCell.js [app-ssr] (ecmascript) {export default as TableCell}");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$TableContainer$2f$TableContainer$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__TableContainer$7d$__ = __turbopack_import__("[project]/node_modules/@material-ui/core/esm/TableContainer/TableContainer.js [app-ssr] (ecmascript) {export default as TableContainer}");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$TableHead$2f$TableHead$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__TableHead$7d$__ = __turbopack_import__("[project]/node_modules/@material-ui/core/esm/TableHead/TableHead.js [app-ssr] (ecmascript) {export default as TableHead}");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$TableRow$2f$TableRow$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__TableRow$7d$__ = __turbopack_import__("[project]/node_modules/@material-ui/core/esm/TableRow/TableRow.js [app-ssr] (ecmascript) {export default as TableRow}");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__TextField$7d$__ = __turbopack_import__("[project]/node_modules/@material-ui/core/esm/TextField/TextField.js [app-ssr] (ecmascript) {export default as TextField}");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/image.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Payments$2f$Payments$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__ = __turbopack_import__("[project]/src/components/Payments/Payments.module.css [app-ssr] (css module)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$genetal$2d$css$2f$general$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__ = __turbopack_import__("[project]/src/components/ui/genetal-css/general.module.css [app-ssr] (css module)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$formateData$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/utils/formateData.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$payments$2f$payments$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/hooks/payments/payments.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Preloader$2f$Preloader$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/Preloader/Preloader.tsx [app-ssr] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
'use client';
;
;
;
;
;
;
;
;
;
const Payments = ({ agentIdError, agentId })=>{
    const { data, isFetching, error } = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$payments$2f$payments$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useGetPaymentsAgent"](agentId);
    if (!data || isFetching) {
        return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Preloader$2f$Preloader$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "<[project]/src/components/Payments/Payments.tsx>",
            lineNumber: 41,
            columnNumber: 16
        }, this);
    }
    if (error || agentIdError) {
        return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("p", {
            className: "text-red-600",
            children: "Ошибка при получении данных"
        }, void 0, false, {
            fileName: "<[project]/src/components/Payments/Payments.tsx>",
            lineNumber: 45,
            columnNumber: 16
        }, this);
    }
    const [dateFilter, setDateFilter] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"]({
        startDate: '',
        endDate: ''
    });
    const [statusFilter, setStatusFilter] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"]('');
    const [openModal, setOpenModal] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"](false);
    const [filteredPayments, setFilteredPayments] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"](()=>[]);
    const isFilterActive = statusFilter || dateFilter.endDate || dateFilter.endDate;
    const handleDateFilterChange = (event)=>{
        const { name, value } = event.target;
        setDateFilter((prevState)=>({
                ...prevState,
                [name]: value
            }));
    };
    const handleStatusFilterChange = (event)=>{
        setStatusFilter(event.target.value);
    };
    const handleModalOpen = ()=>{
        setOpenModal(true);
    };
    const handleModalClose = ()=>{
        setOpenModal(false);
    };
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"](()=>{
        handleFilter();
    }, []);
    const handleFilter = ()=>{
        setOpenModal(false);
        if (!dateFilter.startDate && !dateFilter.endDate && !statusFilter) {
            setFilteredPayments(data.payments);
            return;
        }
        const filteredData = data.payments.filter((payment)=>{
            const paymentDate = payment.dateRequestPayment.split('T')[0];
            const startDate = dateFilter.startDate;
            const endDate = dateFilter.endDate;
            const isDateMatch = (!startDate || paymentDate >= startDate) && (!endDate || paymentDate <= endDate);
            const isStatusMatch = !statusFilter || payment.status.toString() === statusFilter;
            return isDateMatch && isStatusMatch;
        });
        setFilteredPayments(filteredData);
    };
    const handleResetFilter = ()=>{
        setDateFilter({
            startDate: '',
            endDate: ''
        });
        setStatusFilter('');
    };
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("div", {
        className: "pb-6 p-4 text-black shadow-lg",
        children: [
            /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("div", {
                className: "text-center",
                children: [
                    /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("h2", {
                        className: "text-2xl font-bold mb-4",
                        children: "Выплаты:"
                    }, void 0, false, {
                        fileName: "<[project]/src/components/Payments/Payments.tsx>",
                        lineNumber: 120,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("div", {
                        className: "flex items-center justify-center",
                        children: [
                            /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                className: "mb-2",
                                src: "/money.png",
                                alt: "cash",
                                width: 32,
                                height: 32
                            }, void 0, false, {
                                fileName: "<[project]/src/components/Payments/Payments.tsx>",
                                lineNumber: 122,
                                columnNumber: 21
                            }, this),
                            /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("p", {
                                className: "mb-1.5 ml-1.5 text-lg sm:text-xl",
                                children: [
                                    /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("span", {
                                        className: "font-bold",
                                        children: "Баланс: "
                                    }, void 0, false, {
                                        fileName: "<[project]/src/components/Payments/Payments.tsx>",
                                        lineNumber: 124,
                                        columnNumber: 25
                                    }, this),
                                    " ",
                                    /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("span", {
                                        className: "font-light",
                                        children: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$formateData$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["formatPrice"](data.balance)
                                    }, void 0, false, {
                                        fileName: "<[project]/src/components/Payments/Payments.tsx>",
                                        lineNumber: 124,
                                        columnNumber: 69
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "<[project]/src/components/Payments/Payments.tsx>",
                                lineNumber: 123,
                                columnNumber: 21
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "<[project]/src/components/Payments/Payments.tsx>",
                        lineNumber: 121,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("div", {
                        className: "mb-2 sm:mb-5 ml-1.5 text-base sm:text-lg",
                        children: [
                            /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("span", {
                                className: "font-bold text-center",
                                children: "Следующая выплата:"
                            }, void 0, false, {
                                fileName: "<[project]/src/components/Payments/Payments.tsx>",
                                lineNumber: 129,
                                columnNumber: 21
                            }, this),
                            " ",
                            /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("span", {
                                className: "font-bold text-emerald-500 text-center",
                                children: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$formateData$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["formatDate"](data.dateNextPayment)
                            }, void 0, false, {
                                fileName: "<[project]/src/components/Payments/Payments.tsx>",
                                lineNumber: 130,
                                columnNumber: 21
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "<[project]/src/components/Payments/Payments.tsx>",
                        lineNumber: 128,
                        columnNumber: 17
                    }, this)
                ]
            }, void 0, true, {
                fileName: "<[project]/src/components/Payments/Payments.tsx>",
                lineNumber: 119,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("div", {
                className: "relative my-2 sm:mb-3",
                children: [
                    /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("button", {
                        className: `float-right mb-2 sm:mb-4 ${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$genetal$2d$css$2f$general$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].BaseButton}`,
                        onClick: handleModalOpen,
                        children: "Фильтровать"
                    }, void 0, false, {
                        fileName: "<[project]/src/components/Payments/Payments.tsx>",
                        lineNumber: 136,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$TableContainer$2f$TableContainer$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__TableContainer$7d$__["TableContainer"], {
                        component: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$Paper$2f$Paper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__Paper$7d$__["Paper"],
                        children: /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$Table$2f$Table$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__Table$7d$__["Table"], {
                            children: [
                                /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$TableHead$2f$TableHead$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__TableHead$7d$__["TableHead"], {
                                    children: /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$TableRow$2f$TableRow$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__TableRow$7d$__["TableRow"], {
                                        children: [
                                            /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$TableCell$2f$TableCell$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__TableCell$7d$__["TableCell"], {
                                                children: "Номер платежа"
                                            }, void 0, false, {
                                                fileName: "<[project]/src/components/Payments/Payments.tsx>",
                                                lineNumber: 144,
                                                columnNumber: 33
                                            }, this),
                                            /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$TableCell$2f$TableCell$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__TableCell$7d$__["TableCell"], {
                                                children: "Дата следующего платежа"
                                            }, void 0, false, {
                                                fileName: "<[project]/src/components/Payments/Payments.tsx>",
                                                lineNumber: 145,
                                                columnNumber: 33
                                            }, this),
                                            /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$TableCell$2f$TableCell$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__TableCell$7d$__["TableCell"], {
                                                children: "Расчетный счет"
                                            }, void 0, false, {
                                                fileName: "<[project]/src/components/Payments/Payments.tsx>",
                                                lineNumber: 146,
                                                columnNumber: 33
                                            }, this),
                                            /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$TableCell$2f$TableCell$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__TableCell$7d$__["TableCell"], {
                                                children: "Описание"
                                            }, void 0, false, {
                                                fileName: "<[project]/src/components/Payments/Payments.tsx>",
                                                lineNumber: 147,
                                                columnNumber: 33
                                            }, this),
                                            /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$TableCell$2f$TableCell$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__TableCell$7d$__["TableCell"], {
                                                children: "Сумма"
                                            }, void 0, false, {
                                                fileName: "<[project]/src/components/Payments/Payments.tsx>",
                                                lineNumber: 148,
                                                columnNumber: 33
                                            }, this),
                                            /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$TableCell$2f$TableCell$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__TableCell$7d$__["TableCell"], {
                                                children: "Статус"
                                            }, void 0, false, {
                                                fileName: "<[project]/src/components/Payments/Payments.tsx>",
                                                lineNumber: 149,
                                                columnNumber: 33
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "<[project]/src/components/Payments/Payments.tsx>",
                                        lineNumber: 143,
                                        columnNumber: 29
                                    }, this)
                                }, void 0, false, {
                                    fileName: "<[project]/src/components/Payments/Payments.tsx>",
                                    lineNumber: 142,
                                    columnNumber: 25
                                }, this),
                                /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$TableBody$2f$TableBody$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__TableBody$7d$__["TableBody"], {
                                    children: filteredPayments.length > 0 ? filteredPayments.map((payment)=>/*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$TableRow$2f$TableRow$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__TableRow$7d$__["TableRow"], {
                                            className: "hover:bg-gray-100 cursor-pointer",
                                            children: [
                                                /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$TableCell$2f$TableCell$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__TableCell$7d$__["TableCell"], {
                                                    children: payment.paymentId
                                                }, void 0, false, {
                                                    fileName: "<[project]/src/components/Payments/Payments.tsx>",
                                                    lineNumber: 156,
                                                    columnNumber: 41
                                                }, this),
                                                /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$TableCell$2f$TableCell$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__TableCell$7d$__["TableCell"], {
                                                    children: payment.dateRequestPayment.split('T')[0].split('-').reverse().join('.')
                                                }, void 0, false, {
                                                    fileName: "<[project]/src/components/Payments/Payments.tsx>",
                                                    lineNumber: 157,
                                                    columnNumber: 41
                                                }, this),
                                                /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$TableCell$2f$TableCell$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__TableCell$7d$__["TableCell"], {
                                                    children: payment.checkingAccount
                                                }, void 0, false, {
                                                    fileName: "<[project]/src/components/Payments/Payments.tsx>",
                                                    lineNumber: 160,
                                                    columnNumber: 41
                                                }, this),
                                                /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$TableCell$2f$TableCell$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__TableCell$7d$__["TableCell"], {
                                                    children: payment.description
                                                }, void 0, false, {
                                                    fileName: "<[project]/src/components/Payments/Payments.tsx>",
                                                    lineNumber: 161,
                                                    columnNumber: 41
                                                }, this),
                                                /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$TableCell$2f$TableCell$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__TableCell$7d$__["TableCell"], {
                                                    children: `${payment.summa} ₽`
                                                }, void 0, false, {
                                                    fileName: "<[project]/src/components/Payments/Payments.tsx>",
                                                    lineNumber: 162,
                                                    columnNumber: 41
                                                }, this),
                                                /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$TableCell$2f$TableCell$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__TableCell$7d$__["TableCell"], {
                                                    children: [
                                                        payment.status === 2 && 'Выполнено',
                                                        payment.status === 1 && 'Отправлено в банк',
                                                        payment.status === -1 && 'Ошибка'
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "<[project]/src/components/Payments/Payments.tsx>",
                                                    lineNumber: 163,
                                                    columnNumber: 41
                                                }, this)
                                            ]
                                        }, payment.paymentId, true, {
                                            fileName: "<[project]/src/components/Payments/Payments.tsx>",
                                            lineNumber: 155,
                                            columnNumber: 37
                                        }, this)) : /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$TableRow$2f$TableRow$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__TableRow$7d$__["TableRow"], {
                                        children: /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$TableCell$2f$TableCell$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__TableCell$7d$__["TableCell"], {
                                            colSpan: 7,
                                            align: "center",
                                            children: "Нет данных"
                                        }, void 0, false, {
                                            fileName: "<[project]/src/components/Payments/Payments.tsx>",
                                            lineNumber: 171,
                                            columnNumber: 41
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "<[project]/src/components/Payments/Payments.tsx>",
                                        lineNumber: 170,
                                        columnNumber: 37
                                    }, this)
                                }, void 0, false, {
                                    fileName: "<[project]/src/components/Payments/Payments.tsx>",
                                    lineNumber: 152,
                                    columnNumber: 25
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "<[project]/src/components/Payments/Payments.tsx>",
                            lineNumber: 141,
                            columnNumber: 21
                        }, this)
                    }, void 0, false, {
                        fileName: "<[project]/src/components/Payments/Payments.tsx>",
                        lineNumber: 140,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$Dialog$2f$Dialog$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__Dialog$7d$__["Dialog"], {
                        open: openModal,
                        onClose: handleModalClose,
                        "aria-labelledby": "form-dialog-title",
                        fullWidth: true,
                        onKeyDown: (e)=>e.key === 'Enter' && handleFilter(),
                        children: [
                            /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$DialogTitle$2f$DialogTitle$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__DialogTitle$7d$__["DialogTitle"], {
                                id: "form-dialog-title",
                                children: "Фильтр"
                            }, void 0, false, {
                                fileName: "<[project]/src/components/Payments/Payments.tsx>",
                                lineNumber: 182,
                                columnNumber: 21
                            }, this),
                            /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$DialogContent$2f$DialogContent$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__DialogContent$7d$__["DialogContent"], {
                                children: /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("div", {
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Payments$2f$Payments$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].filter_container,
                                    children: [
                                        /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("div", {
                                            className: "w-full",
                                            children: /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__TextField$7d$__["TextField"], {
                                                type: "date",
                                                label: "Начальная дата",
                                                name: "startDate",
                                                className: "w-full",
                                                value: dateFilter.startDate,
                                                onChange: handleDateFilterChange,
                                                InputLabelProps: {
                                                    shrink: true
                                                }
                                            }, void 0, false, {
                                                fileName: "<[project]/src/components/Payments/Payments.tsx>",
                                                lineNumber: 186,
                                                columnNumber: 33
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "<[project]/src/components/Payments/Payments.tsx>",
                                            lineNumber: 185,
                                            columnNumber: 29
                                        }, this),
                                        /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("div", {
                                            className: "mb-3 sm:mb-5"
                                        }, void 0, false, {
                                            fileName: "<[project]/src/components/Payments/Payments.tsx>",
                                            lineNumber: 198,
                                            columnNumber: 29
                                        }, this),
                                        /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("div", {
                                            className: "w-full",
                                            children: /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__TextField$7d$__["TextField"], {
                                                type: "date",
                                                label: "Конечная дата",
                                                name: "endDate",
                                                className: "w-full",
                                                value: dateFilter.endDate,
                                                onChange: handleDateFilterChange,
                                                InputLabelProps: {
                                                    shrink: true
                                                }
                                            }, void 0, false, {
                                                fileName: "<[project]/src/components/Payments/Payments.tsx>",
                                                lineNumber: 200,
                                                columnNumber: 33
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "<[project]/src/components/Payments/Payments.tsx>",
                                            lineNumber: 199,
                                            columnNumber: 29
                                        }, this),
                                        /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("div", {
                                            className: "mb-3 sm:mb-5"
                                        }, void 0, false, {
                                            fileName: "<[project]/src/components/Payments/Payments.tsx>",
                                            lineNumber: 212,
                                            columnNumber: 29
                                        }, this),
                                        /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("div", {
                                            className: "w-full",
                                            children: [
                                                /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$InputLabel$2f$InputLabel$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__InputLabel$7d$__["InputLabel"], {
                                                    id: "status-filter-label",
                                                    children: "Статус"
                                                }, void 0, false, {
                                                    fileName: "<[project]/src/components/Payments/Payments.tsx>",
                                                    lineNumber: 214,
                                                    columnNumber: 33
                                                }, this),
                                                /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$Select$2f$Select$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__Select$7d$__["Select"], {
                                                    labelId: "status-filter-label",
                                                    id: "status-filter",
                                                    value: statusFilter,
                                                    className: "w-full",
                                                    onChange: handleStatusFilterChange,
                                                    children: [
                                                        /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$MenuItem$2f$MenuItem$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__MenuItem$7d$__["MenuItem"], {
                                                            value: "",
                                                            children: "Все"
                                                        }, void 0, false, {
                                                            fileName: "<[project]/src/components/Payments/Payments.tsx>",
                                                            lineNumber: 222,
                                                            columnNumber: 37
                                                        }, this),
                                                        /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$MenuItem$2f$MenuItem$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__MenuItem$7d$__["MenuItem"], {
                                                            value: "2",
                                                            children: "Выполнено"
                                                        }, void 0, false, {
                                                            fileName: "<[project]/src/components/Payments/Payments.tsx>",
                                                            lineNumber: 223,
                                                            columnNumber: 37
                                                        }, this),
                                                        /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$MenuItem$2f$MenuItem$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__MenuItem$7d$__["MenuItem"], {
                                                            value: "1",
                                                            children: "Отправлено в банк"
                                                        }, void 0, false, {
                                                            fileName: "<[project]/src/components/Payments/Payments.tsx>",
                                                            lineNumber: 224,
                                                            columnNumber: 37
                                                        }, this),
                                                        /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$MenuItem$2f$MenuItem$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__MenuItem$7d$__["MenuItem"], {
                                                            value: "-1",
                                                            children: "Ошибка"
                                                        }, void 0, false, {
                                                            fileName: "<[project]/src/components/Payments/Payments.tsx>",
                                                            lineNumber: 225,
                                                            columnNumber: 37
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "<[project]/src/components/Payments/Payments.tsx>",
                                                    lineNumber: 215,
                                                    columnNumber: 33
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "<[project]/src/components/Payments/Payments.tsx>",
                                            lineNumber: 213,
                                            columnNumber: 29
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "<[project]/src/components/Payments/Payments.tsx>",
                                    lineNumber: 184,
                                    columnNumber: 25
                                }, this)
                            }, void 0, false, {
                                fileName: "<[project]/src/components/Payments/Payments.tsx>",
                                lineNumber: 183,
                                columnNumber: 21
                            }, this),
                            /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$material$2d$ui$2f$core$2f$esm$2f$DialogActions$2f$DialogActions$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$7b$export__default__as__DialogActions$7d$__["DialogActions"], {
                                children: /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("div", {
                                    className: "flex flex-col gap-2 sm:flex-row",
                                    children: [
                                        /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("button", {
                                            className: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$genetal$2d$css$2f$general$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].BaseButton} ${isFilterActive ? '' : 'hidden'}`,
                                            onClick: handleResetFilter,
                                            children: "Сбросить фильтр"
                                        }, void 0, false, {
                                            fileName: "<[project]/src/components/Payments/Payments.tsx>",
                                            lineNumber: 232,
                                            columnNumber: 29
                                        }, this),
                                        /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("button", {
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$genetal$2d$css$2f$general$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].BaseButton,
                                            onClick: handleModalClose,
                                            children: "Отменить"
                                        }, void 0, false, {
                                            fileName: "<[project]/src/components/Payments/Payments.tsx>",
                                            lineNumber: 240,
                                            columnNumber: 29
                                        }, this),
                                        /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("button", {
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$genetal$2d$css$2f$general$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].BaseButton,
                                            onClick: handleFilter,
                                            children: "Применить"
                                        }, void 0, false, {
                                            fileName: "<[project]/src/components/Payments/Payments.tsx>",
                                            lineNumber: 243,
                                            columnNumber: 29
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "<[project]/src/components/Payments/Payments.tsx>",
                                    lineNumber: 231,
                                    columnNumber: 25
                                }, this)
                            }, void 0, false, {
                                fileName: "<[project]/src/components/Payments/Payments.tsx>",
                                lineNumber: 230,
                                columnNumber: 21
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "<[project]/src/components/Payments/Payments.tsx>",
                        lineNumber: 180,
                        columnNumber: 17
                    }, this)
                ]
            }, void 0, true, {
                fileName: "<[project]/src/components/Payments/Payments.tsx>",
                lineNumber: 135,
                columnNumber: 13
            }, this)
        ]
    }, void 0, true, {
        fileName: "<[project]/src/components/Payments/Payments.tsx>",
        lineNumber: 118,
        columnNumber: 9
    }, this);
};
const __TURBOPACK__default__export__ = Payments;

})()),
"[project]/src/services/main.service.ts [app-ssr] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_require_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, l: __turbopack_load__, j: __turbopack_dynamic__, p: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "mainService": ()=>mainService
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/axios/lib/axios.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$md5$2f$md5$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/md5/md5.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$js$2d$cookie$2f$dist$2f$js$2e$cookie$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/js-cookie/dist/js.cookie.mjs [app-ssr] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
'use client';
;
;
;
const instance = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].create({
    withCredentials: true,
    baseURL: 'http://95.154.93.88:32768/'
});
__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].interceptors.response.use((config)=>config, async (error)=>{
    const originalRequest = error.config;
    if (error?.response?.data?.answer === -1) {
        originalRequest._isRetry = true;
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$js$2d$cookie$2f$dist$2f$js$2e$cookie$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].remove('token');
    }
    throw error;
});
const doubleMd5 = (password)=>{
    const hash1 = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$md5$2f$md5$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](password).toString();
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$md5$2f$md5$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](hash1).toString();
};
const token = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$js$2d$cookie$2f$dist$2f$js$2e$cookie$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].get('token');
const mainService = {
    // @ts-ignore
    async login ({ login, password }) {
        const { data } = await instance.get(`api/?method=agent.auth&login=${login}&password=${doubleMd5(password)}`);
        return data;
    },
    async getAgentId () {
        const newToken = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$js$2d$cookie$2f$dist$2f$js$2e$cookie$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].get('token');
        const { data } = await instance.get(`http://95.154.93.88:32768/api/?method=agent.id&token=${newToken}`);
        if (data.answer === '-1' || data.answer === '1') {
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$js$2d$cookie$2f$dist$2f$js$2e$cookie$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].remove('token');
        }
        return data;
    },
    async getPaymentsAgent (agentId1) {
        debugger;
        const { data } = await instance.get(`api/?method=agent.payments&token=${token}&agentId=${agentId1}`);
        return data;
    },
    async getAllDrivers ({ offset, count, agentId: agentId1 }) {
        const newToken = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$js$2d$cookie$2f$dist$2f$js$2e$cookie$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].get('token');
        const { data } = await instance.get(`api/?method=driver.getall&token=${newToken}&agentId=${agentId1}&offset=${offset}&count=${count}`);
        return data;
    },
    async getAllOrders ({ offset, count, driverId }) {
        const { data } = await instance.get(`api/?method=driver.orderlist&token=${token}&driverId=${driverId}&offset=${offset}&count=${count}`);
        return data;
    },
    async gerOrderDetails ({ driverId, orderId }) {
        const { data } = await instance.get(`api/?method=driver.orderinfo&token=${token}&driverId=${driverId}&orderId=${orderId}`);
        return data;
    },
    async getDriverInfo ({ driverId }) {
        const { data } = await instance.get(`api/?method=driver.get&token=${token}&driverId=${driverId}`);
        return data;
    },
    async getCarInfo ({ driverId }) {
        const { data } = await instance.get(`api/?method=driver.cars&token=${token}&driverId=${driverId}`);
        return data;
    },
    async getDriverAnalytics ({ driverId, dateFrom, dateTo }) {
        const { data } = await instance.get(`api/?method=driver.analytics&token=${token}&driverId=${driverId}&dateFrom=${dateFrom}&dateTo=${dateTo}`);
        return data;
    },
    async getDriverTransactions ({ driverId }) {
        const { data } = await instance.get(`api/?method=driver.transactions&token=${token}&driverId=${driverId}`);
        return data;
    },
    async createNewCar (requestData, driverId) {
        const formData = new FormData();
        //@ts-ignore
        formData.append('agentId', agentId);
        //@ts-ignore
        formData.append('driverId', requestData.driverId);
        formData.append('token', token);
        formData.append('method', 'driver.car_addedit');
        //@ts-ignore
        Object.entries(requestData.requestData).forEach(([key, value])=>{
            console.log(formData);
            // @ts-ignore
            formData.append(key, value);
        });
        const { data } = await instance.post('api/?method=', formData);
        return data;
    },
    async createNewDriver ({ requestData }) {
        const modifiedRequestData = new FormData();
        //@ts-ignore
        modifiedRequestData.append('agentId', agentId);
        modifiedRequestData.append('token', token);
        modifiedRequestData.append('method', 'driver.addedit');
        Object.entries(requestData.requestData).forEach(([key, value])=>{
            console.log(modifiedRequestData);
            // @ts-ignore
            modifiedRequestData.append(key, value);
        });
        const { data } = await instance.post('api/?method=', modifiedRequestData);
        return data;
    },
    async editDriver ({ requestData, driverId }) {
        const modifiedRequestData = new FormData();
        // @ts-ignore
        modifiedRequestData.append('agentId', agentId);
        modifiedRequestData.append('token', token);
        modifiedRequestData.append('method', 'driver.addedit');
        modifiedRequestData.append('editid', requestData.driverId);
        Object.entries(requestData.requestData).forEach(([key, value])=>{
            // @ts-ignore
            modifiedRequestData.append(key, value);
        });
        const { data } = await instance.post('api/?method=', modifiedRequestData);
        return data;
    },
    async deleteDriver (driverId) {
        const modifiedRequestData = new FormData();
        // @ts-ignore
        modifiedRequestData.append('agentId', agentId);
        modifiedRequestData.append('token', token);
        modifiedRequestData.append('method', 'driver.addedit');
        // @ts-ignore
        modifiedRequestData.append('remove', 1);
        // @ts-ignore
        modifiedRequestData.append('editid', driverId.toString());
        const { data } = await instance.post('api/?method=', modifiedRequestData);
        return data;
    },
    async deleteCar (carId, driverId) {
        const modifiedRequestData = new FormData();
        // @ts-ignore
        modifiedRequestData.append('agentId', agentId);
        // @ts-ignore
        modifiedRequestData.append('driverId', driverId);
        modifiedRequestData.append('token', token);
        modifiedRequestData.append('method', 'driver.car_addedit');
        // @ts-ignore
        modifiedRequestData.append('remove', 1);
        // @ts-ignore
        modifiedRequestData.append('editid', carId.toString());
        const { data } = await instance.post('api/?method=', modifiedRequestData);
        return data;
    }
};

})()),
"[project]/src/hooks/payments/payments.ts [app-ssr] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_require_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, l: __turbopack_load__, j: __turbopack_dynamic__, p: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "useGetPaymentsAgent": ()=>useGetPaymentsAgent
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@tanstack/react-query/build/modern/useQuery.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$main$2e$service$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/services/main.service.ts [app-ssr] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
;
const useGetPaymentsAgent = (agentId)=>{
    debugger;
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useQuery"]({
        queryKey: [
            'getPaymentsAgent'
        ],
        queryFn: async ()=>{
            return __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$main$2e$service$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["mainService"].getPaymentsAgent(agentId);
        }
    });
};

})()),
"[project]/src/components/Preloader/Preloader.module.css [app-ssr] (css module)": (({ r: __turbopack_require__, f: __turbopack_require_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, l: __turbopack_load__, j: __turbopack_dynamic__, p: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname }) => (() => {

__turbopack_export_value__({
  "ball624": "ball624__Preloader__86f17ebc",
  "barUp1": "barUp1__Preloader__86f17ebc",
  "barUp2": "barUp2__Preloader__86f17ebc",
  "barUp3": "barUp3__Preloader__86f17ebc",
  "barUp4": "barUp4__Preloader__86f17ebc",
  "barUp5": "barUp5__Preloader__86f17ebc",
  "loader": "loader__Preloader__86f17ebc",
  "loader__ball": "loader__ball__Preloader__86f17ebc",
  "loader__bar": "loader__bar__Preloader__86f17ebc",
});

})()),
"[project]/src/components/Preloader/Preloader.tsx [app-ssr] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_require_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, l: __turbopack_load__, j: __turbopack_dynamic__, p: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "default": ()=>__TURBOPACK__default__export__
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/server/future/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Preloader$2f$Preloader$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__ = __turbopack_import__("[project]/src/components/Preloader/Preloader.module.css [app-ssr] (css module)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
;
const Preloader = ()=>{
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("div", {
        className: "flex justify-center items-center",
        style: {
            height: '75vh'
        },
        children: /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("div", {
            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Preloader$2f$Preloader$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].loader,
            children: [
                /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Preloader$2f$Preloader$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].loader__bar
                }, void 0, false, {
                    fileName: "<[project]/src/components/Preloader/Preloader.tsx>",
                    lineNumber: 7,
                    columnNumber: 17
                }, this),
                /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Preloader$2f$Preloader$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].loader__bar
                }, void 0, false, {
                    fileName: "<[project]/src/components/Preloader/Preloader.tsx>",
                    lineNumber: 8,
                    columnNumber: 17
                }, this),
                /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Preloader$2f$Preloader$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].loader__bar
                }, void 0, false, {
                    fileName: "<[project]/src/components/Preloader/Preloader.tsx>",
                    lineNumber: 9,
                    columnNumber: 17
                }, this),
                /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Preloader$2f$Preloader$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].loader__bar
                }, void 0, false, {
                    fileName: "<[project]/src/components/Preloader/Preloader.tsx>",
                    lineNumber: 10,
                    columnNumber: 17
                }, this),
                /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Preloader$2f$Preloader$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].loader__bar
                }, void 0, false, {
                    fileName: "<[project]/src/components/Preloader/Preloader.tsx>",
                    lineNumber: 11,
                    columnNumber: 17
                }, this),
                /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Preloader$2f$Preloader$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].loader__ball
                }, void 0, false, {
                    fileName: "<[project]/src/components/Preloader/Preloader.tsx>",
                    lineNumber: 12,
                    columnNumber: 17
                }, this)
            ]
        }, void 0, true, {
            fileName: "<[project]/src/components/Preloader/Preloader.tsx>",
            lineNumber: 6,
            columnNumber: 13
        }, this)
    }, void 0, false, {
        fileName: "<[project]/src/components/Preloader/Preloader.tsx>",
        lineNumber: 5,
        columnNumber: 9
    }, this);
};
const __TURBOPACK__default__export__ = Preloader;

})()),
"[project]/src/components/Layout/Header/Header.tsx [app-ssr] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_require_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, l: __turbopack_load__, j: __turbopack_dynamic__, p: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "default": ()=>__TURBOPACK__default__export__
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/server/future/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/server/future/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/navigation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/link.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/image.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$genetal$2d$css$2f$general$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__ = __turbopack_import__("[project]/src/components/ui/genetal-css/general.module.css [app-ssr] (css module)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$js$2d$cookie$2f$dist$2f$js$2e$cookie$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/js-cookie/dist/js.cookie.mjs [app-ssr] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
'use client';
;
;
;
;
;
;
;
const navLinks = [
    {
        path: "/",
        label: "Водители"
    },
    {
        path: "/payments",
        label: "Выплаты"
    },
    {
        path: "/analytics",
        label: "Аналитика"
    },
    {
        path: "/admin",
        label: "Администратор"
    }
];
const Header = ()=>{
    const pathname = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["usePathname"]();
    const router = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRouter"]();
    const [isMenuOpen, setIsMenuOpen] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"](false);
    const isAdmin = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$js$2d$cookie$2f$dist$2f$js$2e$cookie$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].get("admin") === "1";
    function handleLogout() {
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$js$2d$cookie$2f$dist$2f$js$2e$cookie$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].remove("token");
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$js$2d$cookie$2f$dist$2f$js$2e$cookie$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].remove("agentId");
        router.push("login");
    }
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("div", {
        className: "p-1 sm:p-3 flex justify-between w-full shadow-sm items-center border-b-2",
        children: [
            /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("div", {
                className: "flex items-center",
                children: /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                    href: "/",
                    children: /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("div", {
                        className: "flex items-center cursor-pointer",
                        children: /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                            priority: true,
                            src: "/logo.svg",
                            alt: "Logo",
                            width: 175,
                            height: 115
                        }, void 0, false, {
                            fileName: "<[project]/src/components/Layout/Header/Header.tsx>",
                            lineNumber: 38,
                            columnNumber: 25
                        }, this)
                    }, void 0, false, {
                        fileName: "<[project]/src/components/Layout/Header/Header.tsx>",
                        lineNumber: 37,
                        columnNumber: 21
                    }, this)
                }, void 0, false, {
                    fileName: "<[project]/src/components/Layout/Header/Header.tsx>",
                    lineNumber: 36,
                    columnNumber: 17
                }, this)
            }, void 0, false, {
                fileName: "<[project]/src/components/Layout/Header/Header.tsx>",
                lineNumber: 35,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("div", {
                className: "sm:hidden mr-3",
                children: /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("button", {
                    className: "block text-black",
                    onClick: ()=>setIsMenuOpen(!isMenuOpen),
                    children: /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("svg", {
                        className: "w-6 h-6",
                        fill: "none",
                        stroke: "currentColor",
                        viewBox: "0 0 24 24",
                        xmlns: "http://www.w3.org/2000/svg",
                        children: /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("path", {
                            strokeLinecap: "round",
                            strokeLinejoin: "round",
                            strokeWidth: 2,
                            d: "M4 6h16M4 12h16M4 18h16"
                        }, void 0, false, {
                            fileName: "<[project]/src/components/Layout/Header/Header.tsx>",
                            lineNumber: 60,
                            columnNumber: 25
                        }, this)
                    }, void 0, false, {
                        fileName: "<[project]/src/components/Layout/Header/Header.tsx>",
                        lineNumber: 53,
                        columnNumber: 21
                    }, this)
                }, void 0, false, {
                    fileName: "<[project]/src/components/Layout/Header/Header.tsx>",
                    lineNumber: 49,
                    columnNumber: 17
                }, this)
            }, void 0, false, {
                fileName: "<[project]/src/components/Layout/Header/Header.tsx>",
                lineNumber: 48,
                columnNumber: 13
            }, this),
            isMenuOpen && /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("div", {
                className: "fixed inset-0 bg-white z-50 sm:hidden",
                children: /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("div", {
                    className: "flex flex-col items-center py-8",
                    children: [
                        navLinks.map((link)=>(link.path !== "/admin" || isAdmin) && /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                href: link.path,
                                onClick: ()=>setIsMenuOpen(false),
                                className: `${pathname === link.path ? "relative" : ""} text-black font-bold text-lg transition-color hover:text-emerald-500 mb-4`,
                                children: [
                                    link.label,
                                    pathname === link.path && /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("span", {
                                        className: "absolute bottom-[-5px] left-0 w-full h-1 bg-emerald-600",
                                        "aria-hidden": "true"
                                    }, void 0, false, {
                                        fileName: "<[project]/src/components/Layout/Header/Header.tsx>",
                                        lineNumber: 84,
                                        columnNumber: 37
                                    }, this)
                                ]
                            }, link.path, true, {
                                fileName: "<[project]/src/components/Layout/Header/Header.tsx>",
                                lineNumber: 74,
                                columnNumber: 29
                            }, this)),
                        /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("button", {
                            className: "absolute top-3 right-3",
                            onClick: ()=>setIsMenuOpen(!isMenuOpen),
                            children: /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                src: "/x-mark.svg",
                                alt: "X",
                                width: 30,
                                height: 30
                            }, void 0, false, {
                                fileName: "<[project]/src/components/Layout/Header/Header.tsx>",
                                lineNumber: 95,
                                columnNumber: 29
                            }, this)
                        }, void 0, false, {
                            fileName: "<[project]/src/components/Layout/Header/Header.tsx>",
                            lineNumber: 91,
                            columnNumber: 25
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "<[project]/src/components/Layout/Header/Header.tsx>",
                    lineNumber: 71,
                    columnNumber: 21
                }, this)
            }, void 0, false, {
                fileName: "<[project]/src/components/Layout/Header/Header.tsx>",
                lineNumber: 70,
                columnNumber: 17
            }, this),
            /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("div", {
                className: `${isMenuOpen ? "block" : "hidden"} block sm:flex sm:items-center sm:ml-5`,
                children: navLinks.map((link)=>(link.path !== "/admin" || isAdmin) && /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                        href: link.path,
                        className: `${pathname === link.path ? "relative" : ""} text-black font-bold text-lg transition-color hover:text-emerald-500 mx-3 md:mx-5 lg:mx-7`,
                        children: [
                            link.label,
                            pathname === link.path && /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("span", {
                                className: "absolute bottom-[-25px] left-0 w-full h-1 bg-emerald-600",
                                "aria-hidden": "true"
                            }, void 0, false, {
                                fileName: "<[project]/src/components/Layout/Header/Header.tsx>",
                                lineNumber: 116,
                                columnNumber: 29
                            }, this)
                        ]
                    }, link.path, true, {
                        fileName: "<[project]/src/components/Layout/Header/Header.tsx>",
                        lineNumber: 107,
                        columnNumber: 21
                    }, this))
            }, void 0, false, {
                fileName: "<[project]/src/components/Layout/Header/Header.tsx>",
                lineNumber: 100,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("div", {
                className: `${isMenuOpen ? "block" : "hidden"} block sm:flex sm:items-center sm:ml-5`,
                children: /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("button", {
                    className: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$genetal$2d$css$2f$general$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].BaseButton} min-w-16 text-lg mt-0 lg:mr-3.5`,
                    type: "submit",
                    onClick: handleLogout,
                    children: "Выйти"
                }, void 0, false, {
                    fileName: "<[project]/src/components/Layout/Header/Header.tsx>",
                    lineNumber: 125,
                    columnNumber: 17
                }, this)
            }, void 0, false, {
                fileName: "<[project]/src/components/Layout/Header/Header.tsx>",
                lineNumber: 124,
                columnNumber: 13
            }, this)
        ]
    }, void 0, true, {
        fileName: "<[project]/src/components/Layout/Header/Header.tsx>",
        lineNumber: 34,
        columnNumber: 9
    }, this);
};
const __TURBOPACK__default__export__ = Header;

})()),
"[project]/src/components/Layout/Layout.tsx [app-ssr] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_require_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, l: __turbopack_load__, j: __turbopack_dynamic__, p: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "default": ()=>__TURBOPACK__default__export__
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/server/future/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Layout$2f$Header$2f$Header$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/Layout/Header/Header.tsx [app-ssr] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
;
function Layout({ children }) {
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Layout$2f$Header$2f$Header$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "<[project]/src/components/Layout/Layout.tsx>",
                lineNumber: 6,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("main", {
                className: "mt-4 sm:mt-10",
                children: children
            }, void 0, false, {
                fileName: "<[project]/src/components/Layout/Layout.tsx>",
                lineNumber: 7,
                columnNumber: 13
            }, this)
        ]
    }, void 0, true);
}
const __TURBOPACK__default__export__ = Layout;

})()),
"[project]/src/hooks/drivers/drivers.ts [app-ssr] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_require_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, l: __turbopack_load__, j: __turbopack_dynamic__, p: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "useCreateNewCar": ()=>useCreateNewCar,
    "useCreateNewDriver": ()=>useCreateNewDriver,
    "useDeleteCar": ()=>useDeleteCar,
    "useDeleteDriver": ()=>useDeleteDriver,
    "useEditDriver": ()=>useEditDriver,
    "useGerOrderDetail": ()=>useGerOrderDetail,
    "useGetAgentId": ()=>useGetAgentId,
    "useGetAllDrivers": ()=>useGetAllDrivers,
    "useGetAllOrders": ()=>useGetAllOrders,
    "useGetCarInfo": ()=>useGetCarInfo,
    "useGetDriverAnalytic": ()=>useGetDriverAnalytic,
    "useGetDriverTransactions": ()=>useGetDriverTransactions,
    "useGetDriversInfo": ()=>useGetDriversInfo
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@tanstack/react-query/build/modern/useMutation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@tanstack/react-query/build/modern/useQuery.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@tanstack/react-query/build/modern/QueryClientProvider.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$main$2e$service$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/services/main.service.ts [app-ssr] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
;
const useGetAllDrivers = (offset, count, agentId)=>{
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useQuery"]({
        queryKey: [
            'getAllDrivers'
        ],
        queryFn: async ()=>{
            // @ts-ignore
            return await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$main$2e$service$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["mainService"].getAllDrivers({
                offset,
                count,
                agentId
            });
        }
    });
};
const useGetAllOrders = (offset, count, driverId)=>{
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useQuery"]({
        queryKey: [
            'getAllOrders'
        ],
        queryFn: async ()=>{
            return await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$main$2e$service$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["mainService"].getAllOrders({
                offset,
                count,
                driverId
            });
        }
    });
};
const useGetAgentId = ()=>{
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useQuery"]({
        queryKey: [
            'getAllOrders'
        ],
        queryFn: async ()=>{
            return await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$main$2e$service$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["mainService"].getAgentId();
        }
    });
};
const useGetDriversInfo = (driverId)=>{
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useQuery"]({
        queryKey: [
            'getDriverInfo'
        ],
        queryFn: async ()=>{
            return await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$main$2e$service$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["mainService"].getDriverInfo({
                driverId
            });
        }
    });
};
const useGetDriverAnalytic = (driverId, dateFrom, dateTo, enabled)=>{
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useQuery"]({
        queryKey: [
            'getDriversAnalytic'
        ],
        queryFn: async ()=>{
            return await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$main$2e$service$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["mainService"].getDriverAnalytics({
                driverId,
                dateFrom,
                dateTo
            });
        },
        enabled: enabled
    });
};
const useGerOrderDetail = (driverId, orderId)=>{
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useQuery"]({
        queryKey: [
            'gerOrderDetail'
        ],
        queryFn: async ()=>{
            return await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$main$2e$service$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["mainService"].gerOrderDetails({
                driverId,
                orderId
            });
        }
    });
};
const useGetDriverTransactions = (driverId)=>{
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useQuery"]({
        queryKey: [
            'пetDriverTransactions'
        ],
        queryFn: async ()=>{
            return await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$main$2e$service$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["mainService"].getDriverTransactions({
                driverId
            });
        },
        refetchOnMount: true,
        refetchOnWindowFocus: true
    });
};
const useGetCarInfo = (driverId)=>{
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useQuery"]({
        queryKey: [
            'getCarInfo'
        ],
        queryFn: async ()=>{
            // @ts-ignore
            return await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$main$2e$service$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["mainService"].getCarInfo({
                driverId
            });
        }
    });
};
const useEditDriver = (setRequestErrors, setEditDriverLoading)=>{
    const queryClient = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useQueryClient"]();
    const createNewDriver = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMutation"]({
        mutationKey: [
            'editDriver'
        ],
        // @ts-ignore
        mutationFn: (requestData, driverId)=>{
            setEditDriverLoading(true);
            return __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$main$2e$service$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["mainService"].editDriver({
                requestData,
                driverId
            });
        },
        onSuccess: ()=>{
            setEditDriverLoading(false);
            queryClient.invalidateQueries({
                queryKey: [
                    'getAllDrivers'
                ]
            });
        },
        onError: (error)=>{
            setRequestErrors(error);
            console.log(error);
        }
    });
    const handleCreateEditDriver = (requestData, driverId)=>{
        // @ts-ignore
        createNewDriver.mutate({
            requestData,
            driverId
        });
    };
    return handleCreateEditDriver;
};
const useCreateNewDriver = (setRequestErrors, setCreateNewDriverLoading)=>{
    const queryClient = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useQueryClient"]();
    const createNewDriver = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMutation"]({
        mutationKey: [
            'createNewDriver'
        ],
        // @ts-ignore
        mutationFn: (requestData)=>{
            setCreateNewDriverLoading(true);
            return __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$main$2e$service$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["mainService"].createNewDriver({
                requestData
            });
        },
        onSuccess: ()=>{
            setCreateNewDriverLoading(false);
            queryClient.invalidateQueries({
                queryKey: [
                    'getAllDrivers'
                ]
            });
        },
        onError: (error)=>{
            setRequestErrors(error);
            console.log(error);
        }
    });
    const handleCreateDriver = (requestData)=>{
        // @ts-ignore
        createNewDriver.mutate({
            requestData
        });
    };
    return handleCreateDriver;
};
const useCreateNewCar = (setRequestErrors)=>{
    const queryClient = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useQueryClient"]();
    const createNewCar = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMutation"]({
        mutationKey: [
            'createNewCar'
        ],
        // @ts-ignore
        mutationFn: (requestData, driverId)=>{
            return __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$main$2e$service$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["mainService"].createNewCar(requestData, driverId);
        },
        onSuccess: ()=>{
            queryClient.invalidateQueries({
                queryKey: [
                    'getCarInfo'
                ]
            });
        },
        onError: (error)=>{
            setRequestErrors(error);
            console.log(error);
        }
    });
    const handleCreateNewCar = (requestData, driverId)=>{
        // @ts-ignore
        createNewCar.mutate({
            requestData,
            driverId
        });
    };
    return handleCreateNewCar;
};
const useDeleteDriver = ()=>{
    const queryClient = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useQueryClient"]();
    const deleteDriverMutation = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMutation"]({
        mutationKey: [
            'deleteDriver'
        ],
        // @ts-ignore
        mutationFn: (driverId)=>{
            return __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$main$2e$service$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["mainService"].deleteDriver(driverId);
        },
        onSuccess: ()=>{
            queryClient.invalidateQueries({
                queryKey: [
                    'getAllDrivers'
                ]
            });
        }
    });
    const handleDeleteDriver = (driverId)=>{
        deleteDriverMutation.mutate(driverId);
    };
    return handleDeleteDriver;
};
const useDeleteCar = (driverId)=>{
    const queryClient = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useQueryClient"]();
    const deleteCarMutation = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMutation"]({
        mutationKey: [
            'deleteCar'
        ],
        // @ts-ignore
        mutationFn: (carId)=>{
            return __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$main$2e$service$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["mainService"].deleteCar(carId, driverId);
        },
        onSuccess: ()=>{
            queryClient.invalidateQueries({
                queryKey: [
                    'getCarInfo'
                ]
            });
        }
    });
    const handleDeleteCar = (carId)=>{
        deleteCarMutation.mutate(carId);
    };
    return handleDeleteCar;
};

})()),
"[project]/src/app/payments/page.tsx [app-ssr] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_require_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, l: __turbopack_load__, j: __turbopack_dynamic__, p: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "default": ()=>__TURBOPACK__default__export__
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/server/future/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Payments$2f$Payments$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/Payments/Payments.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/server/future/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Preloader$2f$Preloader$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/Preloader/Preloader.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/navigation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$js$2d$cookie$2f$dist$2f$js$2e$cookie$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/js-cookie/dist/js.cookie.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Layout$2f$Layout$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/Layout/Layout.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$drivers$2f$drivers$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/hooks/drivers/drivers.ts [app-ssr] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
'use client';
;
;
;
;
;
;
;
;
function PaymentsPage() {
    const router = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRouter"]();
    const token = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$js$2d$cookie$2f$dist$2f$js$2e$cookie$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].get('token');
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"](()=>{
        if (!token) {
            router.push('/login');
        }
    }, [
        token
    ]);
    const { data: agentIdData, isFetching: agentIdIsFetching, error: agentIdError } = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$drivers$2f$drivers$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useGetAgentId"]();
    if (!agentIdData || agentIdIsFetching) {
        return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Preloader$2f$Preloader$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "<[project]/src/app/payments/page.tsx>",
            lineNumber: 28,
            columnNumber: 16
        }, this);
    }
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Layout$2f$Layout$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
        children: /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"]("div", {
            className: "mx-5 mt-10",
            children: /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"](__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Payments$2f$Payments$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                agentIdError: agentIdError,
                agentId: agentIdData.agentId
            }, void 0, false, {
                fileName: "<[project]/src/app/payments/page.tsx>",
                lineNumber: 34,
                columnNumber: 17
            }, this)
        }, void 0, false, {
            fileName: "<[project]/src/app/payments/page.tsx>",
            lineNumber: 33,
            columnNumber: 13
        }, this)
    }, void 0, false, {
        fileName: "<[project]/src/app/payments/page.tsx>",
        lineNumber: 32,
        columnNumber: 9
    }, this);
}
const __TURBOPACK__default__export__ = PaymentsPage;

})()),
"[project]/src/app/payments/page.tsx [app-rsc] (ecmascript, Next.js server component, client modules ssr)": (({ r: __turbopack_require__, f: __turbopack_require_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, l: __turbopack_load__, j: __turbopack_dynamic__, p: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname }) => (() => {


})()),

};

//# sourceMappingURL=src_142f2b._.js.map